import React, { useState } from 'react';
import { HashRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { FinanceProvider } from './context/FinanceContext';
import Sidebar from './components/Sidebar';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import TransactionsPage from './pages/TransactionsPage';
import AIChatPage from './pages/AIChatPage';
import VoiceAssistantPage from './pages/VoiceAssistantPage';
import BudgetPlannerPage from './pages/BudgetPlannerPage';
import InsightsPage from './pages/InsightsPage';
import NotificationsPage from './pages/NotificationsPage';
import SettingsPage from './pages/SettingsPage';
import ProfilePage from './pages/ProfilePage';

import { 
  Home, 
  CreditCard, 
  Bot, 
  Mic, 
  User, 
  Menu, 
  X, 
  Bell, 
  Settings 
} from 'lucide-react';

function AppLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Do not show navigation bars on landing and authentication pages
  const isAuthPage = location.pathname === '/auth';
  const isLandingPage = location.pathname === '/' || location.pathname === '';
  
  const showNavs = !isAuthPage && !isLandingPage;

  // Mobile drawer state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  if (!showNavs) {
    return <>{children}</>;
  }

  const mobileNavItems = [
    { label: 'Dash', path: '/dashboard', icon: Home },
    { label: 'Ledger', path: '/transactions', icon: CreditCard },
    { label: 'AI Chat', path: '/ai-chat', icon: Bot },
    { label: 'Voice', path: '/voice', icon: Mic },
    { label: 'Profile', path: '/profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row relative">
      
      {/* Desktop Sidebar (Left) */}
      <div className="hidden md:block">
        <Sidebar />
      </div>

      {/* Mobile Top Navigation Header */}
      <header className="flex md:hidden items-center justify-between px-6 py-4 bg-white border-b border-slate-100 fixed top-0 left-0 right-0 z-40 shadow-sm">
        <div className="flex items-center gap-2" onClick={() => navigate('/dashboard')}>
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-sans font-bold text-sm">
            B
          </div>
          <span className="font-sans font-extrabold text-base text-slate-800">
            Budget<span className="text-blue-600">Buddy</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button 
            id="mobile-alert-btn"
            onClick={() => navigate('/notifications')}
            className="w-9 h-9 bg-slate-50 border border-slate-100 rounded-lg flex items-center justify-center text-slate-500 relative cursor-pointer"
          >
            <Bell className="w-4.5 h-4.5" />
          </button>
          <button 
            id="mobile-settings-btn"
            onClick={() => navigate('/settings')}
            className="w-9 h-9 bg-slate-50 border border-slate-100 rounded-lg flex items-center justify-center text-slate-500 cursor-pointer"
          >
            <Settings className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      {/* Main Page Content Body */}
      <main className="flex-1 min-w-0 pt-16 md:pt-0 pb-20 md:pb-0 overflow-x-hidden">
        {children}
      </main>

      {/* Mobile Bottom Navigation Bar (Fixed bottom) */}
      <nav className="flex md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-slate-100 z-40 justify-around items-center px-4 py-2 shadow-lg">
        {mobileNavItems.map((item) => {
          const isActive = location.pathname === item.path;
          const IconComp = item.icon;
          return (
            <button
              key={item.path}
              id={`mobile-nav-tab-${item.label.toLowerCase()}`}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                isActive ? 'text-blue-600 scale-105' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <IconComp className="w-5 h-5" />
              <span className="text-[10px] font-bold tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>

    </div>
  );
}

export default function App() {
  return (
    <FinanceProvider>
      <HashRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/transactions" element={<TransactionsPage />} />
            <Route path="/ai-chat" element={<AIChatPage />} />
            <Route path="/voice" element={<VoiceAssistantPage />} />
            <Route path="/budget-planner" element={<BudgetPlannerPage />} />
            <Route path="/insights" element={<InsightsPage />} />
            <Route path="/notifications" element={<NotificationsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
          </Routes>
        </AppLayout>
      </HashRouter>
    </FinanceProvider>
  );
}

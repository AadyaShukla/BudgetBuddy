export interface Transaction {
  id: string;
  date: string;
  category: string;
  merchant: string;
  amount: number;
  type: 'income' | 'expense';
  paymentMethod: string;
  status: 'completed' | 'pending';
}

export interface BudgetCategory {
  id: string;
  name: string;
  limit: number;
  spent: number;
  color: string;
  icon: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  category: 'budget' | 'emi' | 'transaction' | 'system';
  read: boolean;
}

export interface UserProfile {
  name: string;
  email: string;
  currency: string;
  language: string;
  theme: 'light' | 'dark';
  offlineMode: boolean;
  notificationsEnabled: boolean;
}

export interface NPUSettings {
  whisperModel: string;
  phiModel: string;
  npuStatus: 'active' | 'inactive' | 'optimizing';
  phiStatus: 'loaded' | 'unloaded' | 'running';
  whisperStatus: 'loaded' | 'unloaded' | 'listening';
  smsPermission: boolean;
  micPermission: boolean;
  storageUsed: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  voiceUrl?: string;
  isSuggested?: boolean;
  explanation?: string;
  cards?: {
    title: string;
    value: string;
    change?: string;
    type?: 'success' | 'warning' | 'danger' | 'info';
  }[];
}

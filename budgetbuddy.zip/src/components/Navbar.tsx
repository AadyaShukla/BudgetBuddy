import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Cpu, Sparkles } from 'lucide-react';

export default function Navbar() {
  const navigate = useNavigate();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          onClick={() => navigate('/')} 
          className="flex items-center gap-2.5 cursor-pointer group"
          id="nav-logo"
        >
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-blue-200 group-hover:scale-105 transition-all">
            <Cpu className="w-5.5 h-5.5" />
          </div>
          <div>
            <span className="font-sans font-bold text-xl tracking-tight text-slate-800">
              Budget<span className="text-blue-600">Buddy</span>
            </span>
            <div className="flex items-center gap-1">
              <span className="text-[9px] font-mono font-medium tracking-widest text-teal-600 uppercase">Snapdragon AI</span>
              <Sparkles className="w-2 h-2 text-teal-500 fill-teal-500 animate-pulse" />
            </div>
          </div>
        </div>

        {/* Navigation links */}
        <div className="hidden md:flex items-center gap-8 font-sans text-sm font-medium text-slate-600">
          <a href="#features" className="hover:text-blue-600 transition-colors">Features</a>
          <a href="#about" className="hover:text-blue-600 transition-colors">About</a>
          <a href="#contact" className="hover:text-blue-600 transition-colors">Contact</a>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-3">
          <button 
            id="nav-login-btn"
            onClick={() => navigate('/auth?tab=login')}
            className="px-4 py-2 text-sm font-semibold text-slate-700 hover:text-blue-600 transition-all rounded-lg"
          >
            Login
          </button>
          <button 
            id="nav-signup-btn"
            onClick={() => navigate('/auth?tab=signup')}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-95 transition-all rounded-xl shadow-md shadow-blue-100"
          >
            Sign Up
          </button>
        </div>
      </div>
    </nav>
  );
}

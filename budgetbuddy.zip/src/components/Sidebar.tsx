import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useFinance } from '../context/FinanceContext';
import { 
  Home, 
  CreditCard, 
  Bot, 
  Mic, 
  PieChart, 
  TrendingUp, 
  Bell, 
  Settings, 
  User, 
  LogOut, 
  Cpu, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { notifications, profile } = useFinance();

  const unreadCount = notifications.filter((n) => !n.read).length;

  const menuItems = [
    { label: 'Dashboard', path: '/dashboard', icon: Home },
    { label: 'Transactions', path: '/transactions', icon: CreditCard },
    { label: 'AI Assistant', path: '/ai-chat', icon: Bot },
    { label: 'Voice', path: '/voice', icon: Mic },
    { label: 'Budget Planner', path: '/budget-planner', icon: PieChart },
    { label: 'Insights', path: '/insights', icon: TrendingUp },
    { 
      label: 'Notifications', 
      path: '/notifications', 
      icon: Bell,
      badge: unreadCount > 0 ? unreadCount : undefined
    },
    { label: 'Settings', path: '/settings', icon: Settings },
    { label: 'Profile', path: '/profile', icon: User },
  ];

  const handleLogout = () => {
    // Clear custom authentication mock states if any, and navigate to landing page
    navigate('/');
  };

  return (
    <aside className="w-64 h-screen bg-white border-r border-slate-100/80 flex flex-col justify-between fixed top-0 left-0 z-40 p-5 shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)]">
      {/* Upper Logo Section */}
      <div className="flex flex-col gap-6">
        <div 
          onClick={() => navigate('/dashboard')} 
          className="flex items-center gap-2.5 cursor-pointer group"
          id="sidebar-logo"
        >
          <div className="w-10 h-10 bg-blue-600 rounded-[14px] flex items-center justify-center text-white shadow-md shadow-blue-100 group-hover:scale-105 transition-all">
            <Cpu className="w-5.5 h-5.5" />
          </div>
          <div>
            <span className="font-sans font-bold text-lg tracking-tight text-slate-800">
              Budget<span className="text-blue-600">Buddy</span>
            </span>
            <div className="flex items-center gap-1">
              <span className="text-[8px] font-mono font-semibold tracking-widest text-teal-600 uppercase">Smart Manager</span>
              <Sparkles className="w-2 h-2 text-teal-500 fill-teal-500 animate-pulse" />
            </div>
          </div>
        </div>

        {/* Security / System Active Indicator Badge */}
        <div className="bg-slate-50/70 border border-slate-100 rounded-2xl p-3 flex items-center gap-2.5">
          <div className="relative">
            <span className="flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-mono font-medium text-slate-400 uppercase tracking-wider">Secured Sandbox</p>
            <p className="text-xs font-semibold text-slate-700 truncate">Sovereign Encryption Active</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex flex-col gap-1" id="sidebar-nav">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            const IconComponent = item.icon;
            
            return (
              <button
                key={item.path}
                id={`sidebar-link-${item.label.toLowerCase().replace(' ', '-')}`}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center justify-between px-4 py-2.5 rounded-2xl font-sans text-sm font-semibold transition-all duration-200 ${
                  isActive 
                    ? 'bg-blue-50/60 text-blue-600 shadow-sm shadow-blue-50/30' 
                    : 'text-slate-500 hover:bg-slate-50/70 hover:text-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <IconComponent className={`w-5 h-5 ${isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-600'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="px-1.5 py-0.5 text-[10px] font-bold bg-blue-600 text-white rounded-full min-w-5 text-center">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* User Session Footer */}
      <div className="flex flex-col gap-4 border-t border-slate-100/80 pt-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center font-sans font-bold text-slate-700 border border-slate-100">
            {profile.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-slate-800 truncate leading-none mb-1">{profile.name}</p>
            <p className="text-[11px] font-medium text-slate-400 truncate leading-none">{profile.email}</p>
          </div>
        </div>

        <button
          id="sidebar-logout-btn"
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-slate-100 text-slate-500 hover:text-red-500 hover:bg-red-50/50 hover:border-red-100 rounded-2xl font-sans text-xs font-semibold transition-all duration-200 active:scale-98"
        >
          <LogOut className="w-4 h-4" />
          <span>Log Out</span>
        </button>
      </div>
    </aside>
  );
}

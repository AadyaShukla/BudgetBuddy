import React, { createContext, useContext, useState, useEffect } from 'react';
import { Transaction, BudgetCategory, NotificationItem, UserProfile, NPUSettings, ChatMessage } from '../types';

export const EXCHANGE_RATES: Record<string, { symbol: string, rate: number, locale: string }> = {
  '$': { symbol: '$', rate: 1, locale: 'en-US' },
  '₹': { symbol: '₹', rate: 83, locale: 'en-IN' },
  '€': { symbol: '€', rate: 0.92, locale: 'de-DE' },
  '£': { symbol: '£', rate: 0.78, locale: 'en-GB' }
};

interface FinanceContextType {
  transactions: Transaction[];
  budgets: BudgetCategory[];
  notifications: NotificationItem[];
  profile: UserProfile;
  npuSettings: NPUSettings;
  chatMessages: ChatMessage[];
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  deleteTransaction: (id: string) => void;
  updateBudgetLimit: (id: string, limit: number) => void;
  updateProfile: (profile: Partial<UserProfile>) => void;
  updateNpuSettings: (settings: Partial<NPUSettings>) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  clearChat: () => void;
  sendMessage: (text: string) => Promise<void>;
  simulateVoiceInput: (transcript: string) => Promise<ChatMessage>;
  voiceLanguage: 'en' | 'hi';
  setVoiceLanguage: (lang: 'en' | 'hi') => void;
  formatCurrency: (amount: number) => string;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

const initialTransactions: Transaction[] = [
  { id: 'tx-1', date: '2026-07-08', category: 'Housing & Rent', merchant: 'Apex Properties', amount: 1200, type: 'expense', paymentMethod: 'Bank Transfer', status: 'completed' },
  { id: 'tx-2', date: '2026-07-07', category: 'Food & Drinks', merchant: 'Whole Foods Market', amount: 154.20, type: 'expense', paymentMethod: 'Credit Card', status: 'completed' },
  { id: 'tx-3', date: '2026-07-06', category: 'Salary', merchant: 'Qualcomm Snapdragon Tech', amount: 5200, type: 'income', paymentMethod: 'Direct Deposit', status: 'completed' },
  { id: 'tx-4', date: '2026-07-05', category: 'Entertainment', merchant: 'Netflix Subscription', amount: 15.99, type: 'expense', paymentMethod: 'Credit Card', status: 'completed' },
  { id: 'tx-5', date: '2026-07-04', category: 'Transport', merchant: 'Tesla Supercharger', amount: 34.50, type: 'expense', paymentMethod: 'Debit Card', status: 'completed' },
  { id: 'tx-6', date: '2026-07-03', category: 'Shopping', merchant: 'Apple Store', amount: 349.00, type: 'expense', paymentMethod: 'Credit Card', status: 'completed' },
  { id: 'tx-7', date: '2026-07-02', category: 'Health', merchant: 'CVS Pharmacy', amount: 45.00, type: 'expense', paymentMethod: 'Debit Card', status: 'completed' },
  { id: 'tx-8', date: '2026-07-01', category: 'Food & Drinks', merchant: 'Blue Bottle Coffee', amount: 18.50, type: 'expense', paymentMethod: 'Apple Pay', status: 'completed' },
  { id: 'tx-9', date: '2026-06-30', category: 'Investment', merchant: 'Robinhood', amount: 200, type: 'income', paymentMethod: 'ACH Transfer', status: 'completed' },
  { id: 'tx-10', date: '2026-06-28', category: 'Transport', merchant: 'Uber Trip', amount: 22.40, type: 'expense', paymentMethod: 'Apple Pay', status: 'completed' },
];

const initialBudgets: BudgetCategory[] = [
  { id: 'b-1', name: 'Housing & Rent', limit: 1500, spent: 1200, color: '#3B82F6', icon: 'Home' },
  { id: 'b-2', name: 'Food & Drinks', limit: 600, spent: 172.70, color: '#10B981', icon: 'Utensils' },
  { id: 'b-3', name: 'Transport', limit: 300, spent: 56.90, color: '#F59E0B', icon: 'Car' },
  { id: 'b-4', name: 'Shopping', limit: 500, spent: 349.00, color: '#EC4899', icon: 'ShoppingBag' },
  { id: 'b-5', name: 'Entertainment', limit: 200, spent: 15.99, color: '#8B5CF6', icon: 'Tv' },
  { id: 'b-6', name: 'Health', limit: 250, spent: 45.00, color: '#EF4444', icon: 'HeartPulse' },
];

const initialNotifications: NotificationItem[] = [
  { id: 'n-1', title: 'Shopping budget alert!', description: 'You have spent 70% of your Shopping budget. Limit: $500, Spent: $349.', timestamp: '2 hours ago', category: 'budget', read: false },
  { id: 'n-2', title: 'Upcoming Laptop EMI Reminder', description: 'Your monthly EMI of $189.00 for Snapdragon Elite Laptop is due on July 15, 2026.', timestamp: '1 day ago', category: 'emi', read: false },
  { id: 'n-3', title: 'Large expense detected', description: 'An expense of $349.00 at Apple Store was successfully categorized under Shopping.', timestamp: '3 days ago', category: 'transaction', read: true },
  { id: 'n-4', title: 'Offline AI Monthly Insight', description: 'Snapdragon NPU analyzed your June spending: food delivery was 12% lower than May. Great job!', timestamp: '5 days ago', category: 'system', read: true },
];

const initialProfile: UserProfile = {
  name: 'Saraswati Choudhary',
  email: 'saraswatichoudhary1997@gmail.com',
  currency: '$',
  language: 'English',
  theme: 'light',
  offlineMode: true,
  notificationsEnabled: true,
};

const initialNpuSettings: NPUSettings = {
  whisperModel: 'Whisper-base.en (Quantized)',
  phiModel: 'Phi-3-mini-4k-instruct-Q4_K_M',
  npuStatus: 'active',
  phiStatus: 'loaded',
  whisperStatus: 'loaded',
  smsPermission: true,
  micPermission: true,
  storageUsed: '4.2 GB / 64 GB',
};

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [budgets, setBudgets] = useState<BudgetCategory[]>(initialBudgets);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initialNotifications);
  const [profile, setProfile] = useState<UserProfile>(initialProfile);
  const [npuSettings, setNpuSettings] = useState<NPUSettings>(initialNpuSettings);
  const [voiceLanguage, setVoiceLanguage] = useState<'en' | 'hi'>('en');

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: "Hello, I am BudgetBuddy, your private AI Financial Companion. I process all your transactions and queries securely. How can I help you optimize your budgets today?",
      timestamp: 'Just now',
    }
  ]);

  const formatCurrency = (amount: number): string => {
    const rateInfo = EXCHANGE_RATES[profile.currency] || EXCHANGE_RATES['$'];
    const converted = amount * rateInfo.rate;
    return `${rateInfo.symbol}${converted.toLocaleString(rateInfo.locale, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  };

  const addTransaction = (tx: Omit<Transaction, 'id'>) => {
    const id = `tx-${Date.now()}`;
    const rateInfo = EXCHANGE_RATES[profile.currency] || EXCHANGE_RATES['$'];
    const amountInUSD = tx.amount / rateInfo.rate;
    const newTx: Transaction = { id, ...tx, amount: amountInUSD };
    setTransactions((prev) => [newTx, ...prev]);

    // Update budget spent
    if (tx.type === 'expense') {
      setBudgets((prev) =>
        prev.map((b) =>
          b.name.toLowerCase() === tx.category.toLowerCase()
            ? { ...b, spent: parseFloat((b.spent + amountInUSD).toFixed(2)) }
            : b
        )
      );

      // Check if this triggers a budget notification
      const updatedBudget = budgets.find((b) => b.name.toLowerCase() === tx.category.toLowerCase());
      if (updatedBudget) {
        const nextSpent = updatedBudget.spent + amountInUSD;
        const percentage = (nextSpent / updatedBudget.limit) * 100;
        if (percentage >= 90) {
          const alertId = `n-${Date.now()}`;
          const newAlert: NotificationItem = {
            id: alertId,
            title: `Critical budget warning: ${updatedBudget.name}!`,
            description: `You have spent ${percentage.toFixed(0)}% of your ${updatedBudget.name} budget. Limit: ${formatCurrency(updatedBudget.limit)}, Spent: ${formatCurrency(nextSpent)}.`,
            timestamp: 'Just now',
            category: 'budget',
            read: false,
          };
          setNotifications((prev) => [newAlert, ...prev]);
        } else if (percentage >= 75) {
          const alertId = `n-${Date.now()}`;
          const newAlert: NotificationItem = {
            id: alertId,
            title: `Budget alert: ${updatedBudget.name}`,
            description: `You have spent ${percentage.toFixed(0)}% of your ${updatedBudget.name} budget. Limit: ${formatCurrency(updatedBudget.limit)}, Spent: ${formatCurrency(nextSpent)}.`,
            timestamp: 'Just now',
            category: 'budget',
            read: false,
          };
          setNotifications((prev) => [newAlert, ...prev]);
        }
      }
    }
  };

  const deleteTransaction = (id: string) => {
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;

    setTransactions((prev) => prev.filter((t) => t.id !== id));

    // Reverse budget spent
    if (tx.type === 'expense') {
      setBudgets((prev) =>
        prev.map((b) =>
          b.name.toLowerCase() === tx.category.toLowerCase()
            ? { ...b, spent: Math.max(0, parseFloat((b.spent - tx.amount).toFixed(2))) }
            : b
        )
      );
    }
  };

  const updateBudgetLimit = (id: string, limit: number) => {
    const rateInfo = EXCHANGE_RATES[profile.currency] || EXCHANGE_RATES['$'];
    const limitInUSD = limit / rateInfo.rate;
    setBudgets((prev) =>
      prev.map((b) => (b.id === id ? { ...b, limit: Math.max(0, limitInUSD) } : b))
    );
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };

  const updateNpuSettings = (updated: Partial<NPUSettings>) => {
    setNpuSettings((prev) => ({ ...prev, ...updated }));
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const clearChat = () => {
    setChatMessages([
      {
        id: 'welcome',
        sender: 'ai',
        text: "Chat cleared. I am ready to assist you. What financial queries do you have?",
        timestamp: 'Just now',
      }
    ]);
  };

  // Offline AI Intelligence Engine
  const generateOfflineAIResponse = async (text: string): Promise<ChatMessage> => {
    const query = text.toLowerCase().trim();
    const timestamp = 'Just now';
    const id = `ai-${Date.now()}`;

    // Compute metrics
    const expenses = transactions.filter((t) => t.type === 'expense');
    const income = transactions.filter((t) => t.type === 'income');
    const totalSpent = expenses.reduce((sum, t) => sum + t.amount, 0);
    const totalEarned = income.reduce((sum, t) => sum + t.amount, 0);
    const netSavings = Math.max(0, totalEarned - totalSpent);

    // Group by category
    const categoryTotals: Record<string, number> = {};
    expenses.forEach((t) => {
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
    });

    if (query.includes('overspend') || query.includes('limit') || query.includes('where did i')) {
      // Find overspent budgets
      const overspent = budgets.filter((b) => b.spent > b.limit);
      if (overspent.length > 0) {
        const listText = overspent
          .map((b) => `${b.name} (Spent: $${b.spent} vs Limit: $${b.limit})`)
          .join(', ');
        return {
          id,
          sender: 'ai',
          text: `Based on your local transaction analysis, you have exceeded your budget in **${overspent.length} category/categories**: ${listText}. I suggest lowering non-essential shopping or dining to compensate.`,
          timestamp,
          explanation: "Analyzed your core financial metrics instantly to build this budget profile.",
          cards: overspent.map((b) => ({
            title: b.name,
            value: `$${(b.spent - b.limit).toFixed(2)} Over`,
            change: `${((b.spent / b.limit) * 100).toFixed(0)}% of limit`,
            type: 'danger'
          }))
        };
      } else {
        // High budget health
        const highestPercentageCategory = budgets
          .map((b) => ({ ...b, pct: (b.spent / b.limit) * 100 }))
          .sort((a, b) => b.pct - a.pct)[0];

        return {
          id,
          sender: 'ai',
          text: `Excellent news! None of your budget categories are currently over-limit. Your closest watch-out category is **${highestPercentageCategory.name}** which is at **${highestPercentageCategory.pct.toFixed(0)}%** of its limit ($${highestPercentageCategory.spent} spent of $${highestPercentageCategory.limit}).`,
          timestamp,
          explanation: "Analyzed your savings data and categories securely.",
          cards: [
            { title: 'Budget Health Score', value: '94/100', change: 'Outstanding', type: 'success' },
            { title: 'Closest Watch', value: highestPercentageCategory.name, change: `${highestPercentageCategory.pct.toFixed(0)}% used`, type: 'warning' }
          ]
        };
      }
    }

    if (query.includes('save') || query.includes('savings') || query.includes('can i save')) {
      const savingsRate = totalEarned > 0 ? (netSavings / totalEarned) * 100 : 0;
      let recommendations = '';
      if (savingsRate < 20) {
        recommendations = "Your savings rate is below the recommended 20%. Let's adjust your Transport and Entertainment limits. For instance, reducing Entertainment from $200 to $120 will free up an extra $80/month.";
      } else {
        recommendations = `Fantastic work! Your current savings rate is **${savingsRate.toFixed(1)}%** ($${netSavings.toFixed(2)} saved). You are on track to exceed your savings projection for the quarter.`;
      }

      return {
        id,
        sender: 'ai',
        text: recommendations,
        timestamp,
        explanation: "Savings projections computed dynamically using standard regression models.",
        cards: [
          { title: 'Monthly Income', value: `$${totalEarned.toFixed(2)}`, type: 'info' },
          { title: 'Monthly Spending', value: `$${totalSpent.toFixed(2)}`, type: 'danger' },
          { title: 'Net Savings', value: `$${netSavings.toFixed(2)}`, type: 'success' },
        ]
      };
    }

    if (query.includes('recur') || query.includes('recurring') || query.includes('subscription') || query.includes('emi')) {
      const subscriptions = expenses.filter(
        (t) =>
          t.merchant.toLowerCase().includes('netflix') ||
          t.merchant.toLowerCase().includes('spotify') ||
          t.merchant.toLowerCase().includes('sub') ||
          t.merchant.toLowerCase().includes('apex') ||
          t.category.toLowerCase().includes('housing')
      );
      const totalRecurring = subscriptions.reduce((sum, t) => sum + t.amount, 0);

      return {
        id,
        sender: 'ai',
        text: `I identified **${subscriptions.length} recurring expenses** summing up to **$${totalRecurring.toFixed(2)}/month**. This includes your rent at Apex Properties ($1,200.00) and subscription services like Netflix ($15.99).`,
        timestamp,
        explanation: "Pattern matching verified recurrence indices on ledger data.",
        cards: subscriptions.map((s) => ({
          title: s.merchant,
          value: `$${s.amount.toFixed(2)}/mo`,
          change: s.category,
          type: 'info'
        }))
      };
    }

    // Default response if no keyword matched
    return {
      id,
      sender: 'ai',
      text: `Your premium BudgetBuddy AI received: "${text}".\n\nI can assist you with precise calculations on your secure transactions. Try asking me:\n- *"Where did I overspend this month?"*\n- *"How much can I save?"*\n- *"What are my recurring expenses?"*`,
      timestamp,
      explanation: "AI processed this response securely using local data analysis."
    };
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now',
    };

    setChatMessages((prev) => [...prev, userMsg]);

    // Simulate thinking state briefly
    await new Promise((resolve) => setTimeout(resolve, 600));

    const aiMsg = await generateOfflineAIResponse(text);
    setChatMessages((prev) => [...prev, aiMsg]);
  };

  const simulateVoiceInput = async (transcript: string): Promise<ChatMessage> => {
    // Add user voice input
    const userMsg: ChatMessage = {
      id: `user-voice-${Date.now()}`,
      sender: 'user',
      text: transcript,
      timestamp: 'Just now',
    };

    setChatMessages((prev) => [...prev, userMsg]);

    // Get response
    const aiMsg = await generateOfflineAIResponse(transcript);
    setChatMessages((prev) => [...prev, aiMsg]);
    return aiMsg;
  };

  return (
    <FinanceContext.Provider
      value={{
        transactions,
        budgets,
        notifications,
        profile,
        npuSettings,
        chatMessages,
        addTransaction,
        deleteTransaction,
        updateBudgetLimit,
        updateProfile,
        updateNpuSettings,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        clearChat,
        sendMessage,
        simulateVoiceInput,
        voiceLanguage,
        setVoiceLanguage,
        formatCurrency,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};

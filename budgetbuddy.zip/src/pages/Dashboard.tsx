import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFinance } from '../context/FinanceContext';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Plus, 
  Mic, 
  FileText, 
  PieChart as ChartIcon, 
  TrendingUp, 
  Bell, 
  Calendar, 
  CreditCard, 
  UserCheck,
  X,
  Sparkles,
  Search,
  Check
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';

export default function Dashboard() {
  const navigate = useNavigate();
  const { 
    transactions, 
    budgets, 
    notifications, 
    profile, 
    addTransaction,
    deleteTransaction,
    formatCurrency
  } = useFinance();

  // Modal States
  const [isAddTxOpen, setIsAddTxOpen] = useState(false);
  const [isScanReceiptOpen, setIsScanReceiptOpen] = useState(false);

  // New Transaction Form State
  const [txMerchant, setTxMerchant] = useState('');
  const [txAmount, setTxAmount] = useState('');
  const [txCategory, setTxCategory] = useState('Food & Drinks');
  const [txType, setTxType] = useState<'income' | 'expense'>('expense');
  const [txMethod, setTxMethod] = useState('Credit Card');
  const [txDate, setTxDate] = useState('2026-07-09');

  // OCR Simulator State
  const [scannedFile, setScannedFile] = useState<File | null>(null);
  const [scanning, setScanning] = useState(false);
  const [scannedResult, setScannedResult] = useState<{ merchant: string; amount: number; category: string } | null>(null);

  // Compute financial totals dynamically from context
  const expenses = transactions.filter((t) => t.type === 'expense');
  const income = transactions.filter((t) => t.type === 'income');
  
  const totalSpending = expenses.reduce((sum, t) => sum + t.amount, 0);
  const totalSavings = Math.max(0, income.reduce((sum, t) => sum + t.amount, 0) - totalSpending);
  
  const totalBudgetLimit = budgets.reduce((sum, b) => sum + b.limit, 0);
  const totalBudgetSpent = budgets.reduce((sum, b) => sum + b.spent, 0);
  const remainingBudget = Math.max(0, totalBudgetLimit - totalBudgetSpent);

  // Financial Health Assessment calculations
  const overspentCategoriesCount = budgets.filter((b) => b.spent > b.limit).length;
  const baseScore = 95;
  const penalty = overspentCategoriesCount * 15;
  const totalIncome = income.reduce((sum, t) => sum + t.amount, 0);
  const savingsRatio = totalIncome > 0 ? (totalSavings / totalIncome) : 0;
  const scoreBonus = Math.min(10, Math.floor(savingsRatio * 20));
  const healthScore = Math.max(20, Math.min(100, baseScore - penalty + scoreBonus));

  // Recharts Line Chart Data: group spending by day
  const dailySpendingData = [
    { name: 'Mon', amount: 45.00 },
    { name: 'Tue', amount: 18.50 },
    { name: 'Wed', amount: 34.50 },
    { name: 'Thu', amount: 349.00 },
    { name: 'Fri', amount: 15.99 },
    { name: 'Sat', amount: 154.20 },
    { name: 'Sun', amount: 1200.00 }
  ];

  // Recharts Pie Chart Data: group spent by category
  const pieData = budgets.map((b) => ({
    name: b.name,
    value: b.spent,
    color: b.color
  }));

  const handleAddTxSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!txMerchant || !txAmount) return;

    addTransaction({
      date: txDate,
      category: txCategory,
      merchant: txMerchant,
      amount: parseFloat(txAmount),
      type: txType,
      paymentMethod: txMethod,
      status: 'completed'
    });

    // Reset Form
    setTxMerchant('');
    setTxAmount('');
    setIsAddTxOpen(false);
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setScannedFile(file);
      setScanning(true);
      setScannedResult(null);

      // Simulate local Snapdragon OCR running on NPU
      setTimeout(() => {
        setScanning(false);
        setScannedResult({
          merchant: 'Starbucks Coffee',
          amount: 14.50,
          category: 'Food & Drinks'
        });
      }, 1500);
    }
  };

  const applyScannedReceipt = () => {
    if (!scannedResult) return;
    addTransaction({
      date: '2026-07-09',
      category: scannedResult.category,
      merchant: scannedResult.merchant,
      amount: scannedResult.amount,
      type: 'expense',
      paymentMethod: 'Apple Pay',
      status: 'completed'
    });
    // Reset scanner
    setScannedFile(null);
    setScannedResult(null);
    setIsScanReceiptOpen(false);
  };

  // Dynamically calculate top spending category
  const categorySpent = budgets.reduce((acc, b) => {
    acc[b.name] = b.spent;
    return acc;
  }, {} as Record<string, number>);
  const topCategoryName = Object.keys(categorySpent).length > 0 
    ? Object.keys(categorySpent).reduce((a, b) => categorySpent[a] > categorySpent[b] ? a : b)
    : 'N/A';
  const topCategoryValue = categorySpent[topCategoryName] || 0;

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left">
      {/* Dashboard Top Greeting */}
      <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 animate-fade-in">
        <div>
          <h1 className="font-sans font-extrabold text-3xl text-slate-900 tracking-tight">
            Hello, {profile.name.split(' ')[0]}
          </h1>
          <p className="font-sans text-sm font-semibold text-slate-400 mt-1 flex items-center gap-1.5">
            <span>Your Smart Personal Finance Dashboard</span>
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block"></span>
            <span className="text-emerald-600">Secure Account Balance</span>
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-white border border-slate-100 rounded-2xl px-4 py-2 flex items-center gap-2 shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] text-sm font-bold text-slate-600">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span>July 2026</span>
          </div>
          <button 
            id="dash-notif-btn"
            onClick={() => navigate('/notifications')}
            className="w-10 h-10 bg-white border border-slate-100 rounded-2xl flex items-center justify-center relative hover:bg-slate-50 cursor-pointer shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] transition-all"
          >
            <Bell className="w-5 h-5 text-slate-600" />
            {notifications.filter(n => !n.read).length > 0 && (
              <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full"></span>
            )}
          </button>
        </div>
      </header>

      {/* Visual Wealth Insights & Cash Flow Dashboard Header Widget */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
        
        {/* Dynamic Financial Health Score Gauge (5 cols) */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-slate-800 p-6 rounded-[24px] text-white shadow-lg relative overflow-hidden flex flex-col justify-between min-h-[220px]">
          <div className="absolute -right-16 -bottom-16 w-48 h-48 bg-blue-500 rounded-full blur-3xl opacity-20 pointer-events-none"></div>
          <div className="absolute -left-16 -top-16 w-48 h-48 bg-teal-500 rounded-full blur-3xl opacity-10 pointer-events-none"></div>

          <div className="flex items-center justify-between mb-4 relative z-10">
            <div>
              <p className="text-[10px] font-mono font-bold uppercase tracking-widest text-blue-400">Personal Health Monitor</p>
              <h3 className="font-sans font-bold text-lg text-slate-100 mt-0.5">Financial Health Score</h3>
            </div>
            <span className="bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-mono px-2 py-0.5 rounded-md font-bold">
              PORTFOLIO ACTIVE
            </span>
          </div>

          <div className="flex items-center gap-6 my-2 relative z-10">
            {/* Dynamic circular progress gauge */}
            <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
              <svg className="w-full h-full transform -rotate-90">
                <circle 
                  cx="56" 
                  cy="56" 
                  r="46" 
                  stroke="#1E293B" 
                  strokeWidth="8" 
                  fill="transparent" 
                />
                <circle 
                  cx="56" 
                  cy="56" 
                  r="46" 
                  stroke={healthScore > 80 ? '#10B981' : healthScore > 60 ? '#F59E0B' : '#EF4444'} 
                  strokeWidth="8" 
                  fill="transparent" 
                  strokeDasharray={`${2 * Math.PI * 46}`}
                  strokeDashoffset={`${2 * Math.PI * 46 * (1 - healthScore / 100)}`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-3xl font-black text-white">{healthScore}</span>
                <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">Score</span>
              </div>
            </div>

            <div className="flex flex-col gap-1.5 text-left">
              <span className={`text-sm font-bold ${healthScore > 80 ? 'text-emerald-400' : healthScore > 60 ? 'text-amber-400' : 'text-rose-400'}`}>
                {healthScore > 80 ? 'Excellent Standing' : healthScore > 60 ? 'Healthy Limits' : 'Watch Your Budget'}
              </span>
              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                {overspentCategoriesCount > 0 
                  ? `You have overspent in ${overspentCategoriesCount} budget categories. Bring them down to boost your score.` 
                  : "All budget caps are intact, and your savings rate is positive. Keep it up!"}
              </p>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-3.5 mt-2 flex items-center justify-between text-[10px] font-mono text-slate-400 relative z-10">
            <span>HEALTH STATE: SECURE</span>
            <span>RATIO: {(savingsRatio * 100).toFixed(0)}% SAVED</span>
          </div>
        </div>

        {/* Dynamic Cash Flow Bar Chart Card (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col justify-between min-h-[220px]">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-sans font-bold text-base text-slate-800">Monthly Cash Flow Comparison</h3>
              <p className="text-xs font-semibold text-slate-400 mt-0.5">Visual ratio of total income against outlays</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span>Inflow</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-rose-500">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                <span>Outflow</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-4 my-3">
            {/* Income Bar */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-slate-500">Total Money Received (Inflow)</span>
                <span className="text-emerald-600">{formatCurrency(totalIncome)}</span>
              </div>
              <div className="w-full bg-slate-50 border border-slate-100 h-3.5 rounded-xl overflow-hidden">
                <div className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-xl transition-all" style={{ width: totalIncome > 0 ? '100%' : '0%' }}></div>
              </div>
            </div>

            {/* Spending Bar */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between items-center text-xs font-bold">
                <span className="text-slate-500">Total Money Spent (Outflow)</span>
                <span className="text-rose-500">{formatCurrency(totalSpending)}</span>
              </div>
              <div className="w-full bg-slate-50 border border-slate-100 h-3.5 rounded-xl overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-rose-500 to-amber-500 h-full rounded-xl transition-all" 
                  style={{ width: totalIncome > 0 ? `${Math.min(100, (totalSpending / totalIncome) * 100)}%` : '0%' }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-100/60 rounded-xl px-4 py-2 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Net Savings Buffer</span>
            <span className="text-sm font-extrabold text-slate-800">{formatCurrency(totalSavings)}</span>
          </div>
        </div>

      </section>

      {/* Grid of Overview Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" id="overview-cards">
        {/* Monthly Spending */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Monthly Spending</span>
            <span className="p-1.5 bg-rose-50 text-rose-600 rounded-lg text-xs font-bold">Outflow</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{formatCurrency(totalSpending)}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <ArrowDownRight className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-bold text-emerald-600">12% lower</span>
            <span className="text-[10px] font-medium text-slate-400">vs last month</span>
          </div>
        </div>

        {/* Monthly Income */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Monthly Income</span>
            <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-bold">Inflow</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{formatCurrency(totalIncome)}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <ArrowUpRight className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-bold text-emerald-600">Direct Deposit</span>
            <span className="text-[10px] font-medium text-slate-400">Regular</span>
          </div>
        </div>

        {/* Remaining Budget */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Remaining Budget</span>
            <span className="p-1.5 bg-teal-50 text-teal-600 rounded-lg text-xs font-bold">Safety</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{formatCurrency(remainingBudget)}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-teal-500 h-full rounded-full transition-all" 
                style={{ width: `${Math.min(100, (totalBudgetSpent / totalBudgetLimit) * 100)}%` }}
              ></div>
            </div>
            <span className="text-xs font-bold text-slate-500 shrink-0">
              {((totalBudgetSpent / totalBudgetLimit) * 100).toFixed(0)}% used
            </span>
          </div>
        </div>

        {/* Savings */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Savings</span>
            <span className="p-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold">Reserved</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{formatCurrency(totalSavings)}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <ArrowUpRight className="w-4 h-4 text-emerald-500" />
            <span className="text-xs font-bold text-emerald-600">+8.4% growth</span>
            <span className="text-[10px] font-medium text-slate-400">vs target</span>
          </div>
        </div>

        {/* Upcoming Bills */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Upcoming Bills</span>
            <span className="p-1.5 bg-orange-50 text-orange-600 rounded-lg text-xs font-bold">Utility</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{formatCurrency(85.99)}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <span className="w-2 h-2 rounded-full bg-orange-500"></span>
            <span className="text-xs font-bold text-orange-600">Due in 4 Days</span>
            <span className="text-[10px] font-medium text-slate-400">Broadband & Cloud Storage</span>
          </div>
        </div>

        {/* Upcoming EMI */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Upcoming EMI</span>
            <span className="p-1.5 bg-amber-50 text-amber-600 rounded-lg text-xs font-bold">Loans</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{formatCurrency(189.00)}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span className="text-xs font-bold text-amber-600">Due July 15</span>
            <span className="text-[10px] font-medium text-slate-400">Car Loan Repayment</span>
          </div>
        </div>

        {/* Top Spending Category */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Top Category</span>
            <span className="p-1.5 bg-purple-50 text-purple-600 rounded-lg text-xs font-bold">Trends</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight truncate">{topCategoryName}</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <span className="text-xs font-bold text-purple-600">{formatCurrency(topCategoryValue)} spent</span>
            <span className="text-[10px] font-medium text-slate-400">This Month</span>
          </div>
        </div>

        {/* Financial Health Score (Repeated/Linked summary) */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <div className="flex justify-between items-start mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Health Status</span>
            <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-bold">Monitor</span>
          </div>
          <p className="text-2xl font-extrabold text-slate-800 tracking-tight">{healthScore} / 100</p>
          <div className="flex items-center gap-1.5 mt-2.5">
            <span className="text-xs font-bold text-emerald-600">Stable Index</span>
            <span className="text-[10px] font-medium text-slate-400">Secure Audit</span>
          </div>
        </div>
      </section>

      {/* Main Grid Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left 8-column Panel */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          
          {/* Recharts Analytics Charts panel */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-sans font-bold text-lg text-slate-800">Dynamic Spend Charts</h2>
                <p className="text-xs font-semibold text-slate-400 mt-0.5">Real-time local analysis of categories and trends</p>
              </div>
              <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 px-2.5 py-1 rounded-lg text-[10px] font-bold border border-blue-100 uppercase tracking-wider">
                <Sparkles className="w-3 h-3 animate-pulse text-blue-500 fill-blue-500" />
                <span>Secured Analysis</span>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Category-wise Pie Chart (5 columns) */}
              <div className="md:col-span-5 border border-slate-100/60 p-4 rounded-2xl flex flex-col items-center justify-center">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 self-start">By Category</p>
                <div className="w-full h-48 relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [formatCurrency(Number(value)), 'Amount']} />
                    </PieChart>
                  </ResponsiveContainer>
                  {/* Absolute core metrics indicator */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-2">
                    <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider">Total</span>
                    <span className="text-base font-extrabold text-slate-700">{formatCurrency(totalSpending)}</span>
                  </div>
                </div>
                {/* Micro legends */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 mt-4 w-full">
                  {pieData.map((d, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 truncate">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }}></span>
                      <span className="truncate">{d.name} ({formatCurrency(d.value)})</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Weekly Spending Line Chart (7 columns) */}
              <div className="md:col-span-7 border border-slate-100/60 p-4 rounded-2xl flex flex-col">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Weekly Spending Cycle</p>
                <div className="w-full h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={dailySpendingData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                      <XAxis dataKey="name" stroke="#94A3B8" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#94A3B8" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => formatCurrency(Number(value))} />
                      <Tooltip formatter={(value) => [formatCurrency(Number(value)), 'Spent']} />
                      <Line 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="#2563EB" 
                        strokeWidth={3} 
                        dot={{ r: 4, stroke: '#2563EB', strokeWidth: 2, fill: '#FFF' }}
                        activeDot={{ r: 6 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>

          {/* Budget Progress bars */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="font-sans font-bold text-lg text-slate-800">Budget Progress Bars</h2>
                <p className="text-xs font-semibold text-slate-400 mt-0.5">Category targets vs real-time spending</p>
              </div>
              <button 
                id="dash-edit-budget-btn"
                onClick={() => navigate('/budget-planner')}
                className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1"
              >
                <span>Edit Limits</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {budgets.map((b) => {
                const pct = Math.min(100, (b.spent / b.limit) * 100);
                const isOver = b.spent > b.limit;
                return (
                  <div key={b.id} className="border border-slate-100/60 p-4 rounded-2xl flex flex-col gap-3">
                    <div className="flex justify-between items-center text-sm font-bold">
                      <span className="text-slate-700 flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: b.color }}></span>
                        {b.name}
                      </span>
                      <span className={isOver ? 'text-red-600' : 'text-slate-500'}>
                        {formatCurrency(b.spent)} / {formatCurrency(b.limit)}
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden relative">
                      <div 
                        className="h-full rounded-full transition-all" 
                        style={{ 
                          width: `${pct}%`,
                          backgroundColor: isOver ? '#EF4444' : b.color 
                        }}
                      ></div>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-bold">
                      <span className={isOver ? 'text-red-500' : 'text-slate-400'}>
                        {isOver ? 'Limit exceeded!' : formatCurrency(b.limit - b.spent) + ' left'}
                      </span>
                      <span className="text-slate-400">{pct.toFixed(0)}% used</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Activity Timeline */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5">
            <div>
              <h2 className="font-sans font-bold text-lg text-slate-800">Recent Transactions</h2>
              <p className="text-xs font-semibold text-slate-400 mt-0.5">Latest transaction journal entries</p>
            </div>

            <div className="flex flex-col gap-3">
              {transactions.slice(0, 5).map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3.5 bg-slate-50/30 hover:bg-slate-50/70 border border-slate-100/40 rounded-2xl transition-all group">
                  <div className="flex items-center gap-3.5">
                    <div className={`w-10 h-10 rounded-2xl border flex items-center justify-center font-bold text-base bg-white shadow-sm shrink-0`}>
                      {tx.category === 'Food & Drinks' ? '🍱' : 
                       tx.category === 'Shopping' ? '🛍️' : 
                       tx.category === 'Salary' ? '💵' : 
                       tx.category === 'Transport' ? '🚗' : 
                       tx.category === 'Entertainment' ? '🎬' : '📝'}
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold text-slate-800 group-hover:text-blue-600 transition-colors">{tx.merchant}</p>
                      <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mt-0.5">{tx.category} • {tx.paymentMethod}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-bold ${tx.type === 'income' ? 'text-emerald-600' : 'text-red-600'}`}>
                      {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </p>
                    <p className="text-[10px] font-mono text-slate-400 mt-0.5">{tx.date}</p>
                  </div>
                </div>
              ))}
            </div>

            <button 
              id="dash-view-all-tx-btn"
              onClick={() => navigate('/transactions')}
              className="py-3 text-sm font-bold text-blue-600 hover:text-blue-700 bg-blue-50/30 hover:bg-blue-50/60 rounded-2xl transition-colors text-center cursor-pointer"
            >
              View All Transactions Journal
            </button>
          </div>
        </div>

        {/* Right 4-column Panel */}
        <div className="lg:col-span-4 flex flex-col gap-8">
          
          {/* Quick Actions Panel */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
            <h2 className="font-sans font-bold text-lg text-slate-800 mb-2">Quick Actions</h2>
            
            <div className="grid grid-cols-2 gap-3">
              <button
                id="action-add-tx-btn"
                onClick={() => setIsAddTxOpen(true)}
                className="p-4 bg-blue-50/40 hover:bg-blue-50 border border-blue-100/40 text-blue-700 rounded-2xl flex flex-col items-center justify-center gap-2.5 transition-all active:scale-95 text-center cursor-pointer shadow-[0_4px_12px_rgba(37,99,235,0.02)] group"
              >
                <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center shadow-md shadow-blue-100 group-hover:scale-105 transition-all">
                  <Plus className="w-5.5 h-5.5" />
                </div>
                <span className="text-xs font-bold leading-none">Add Expense</span>
              </button>

              <button
                id="action-planner-btn"
                onClick={() => navigate('/budget-planner')}
                className="p-4 bg-purple-50/40 hover:bg-purple-50 border border-purple-100/40 text-purple-700 rounded-2xl flex flex-col items-center justify-center gap-2.5 transition-all active:scale-95 text-center cursor-pointer shadow-[0_4px_12px_rgba(147,51,234,0.02)] group"
              >
                <div className="w-10 h-10 bg-purple-600 text-white rounded-xl flex items-center justify-center shadow-md shadow-purple-100 group-hover:scale-105 transition-all">
                  <ChartIcon className="w-5.5 h-5.5" />
                </div>
                <span className="text-xs font-bold leading-none">Budget Planner</span>
              </button>

              <button
                id="action-insights-btn"
                onClick={() => navigate('/insights')}
                className="p-4 bg-teal-50/40 hover:bg-teal-50 border border-teal-100/40 text-teal-700 rounded-2xl flex flex-col items-center justify-center gap-2.5 transition-all active:scale-95 text-center cursor-pointer shadow-[0_4px_12px_rgba(15,118,110,0.02)] group"
              >
                <div className="w-10 h-10 bg-teal-600 text-white rounded-xl flex items-center justify-center shadow-md shadow-teal-100 group-hover:scale-105 transition-all">
                  <TrendingUp className="w-5.5 h-5.5" />
                </div>
                <span className="text-xs font-bold leading-none">View Insights</span>
              </button>

              <button
                id="action-voice-btn"
                onClick={() => navigate('/voice')}
                className="p-4 bg-amber-50/40 hover:bg-amber-50 border border-amber-100/40 text-amber-700 rounded-2xl flex flex-col items-center justify-center gap-2.5 transition-all active:scale-95 text-center cursor-pointer shadow-[0_4px_12px_rgba(217,119,6,0.02)] group"
              >
                <div className="w-10 h-10 bg-amber-600 text-white rounded-xl flex items-center justify-center shadow-md shadow-amber-100 group-hover:scale-105 transition-all">
                  <Mic className="w-5.5 h-5.5" />
                </div>
                <span className="text-xs font-bold leading-none">Voice Assistant</span>
              </button>
            </div>
          </div>

          {/* Investment Suggestions Panel */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
            <div className="flex items-center gap-2 justify-between">
              <h2 className="font-sans font-bold text-lg text-slate-800">Investment Suggestions</h2>
              <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-100 uppercase">Govt & Bank Approved</span>
            </div>
            <div className="flex flex-col gap-3">
              <div className="bg-blue-50/40 rounded-2xl border border-blue-100/30 p-3.5 text-left flex flex-col gap-1.5">
                <span className="text-xs font-extrabold text-blue-700 uppercase tracking-wide">Bank Fixed Deposits (FDs)</span>
                <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                  Earn up to <strong className="text-slate-800">7.8% p.a.</strong> secure returns with leading commercial banks. Keep emergency savings liquid while beating inflation safely.
                </p>
              </div>
              <div className="bg-purple-50/40 rounded-2xl border border-purple-100/30 p-3.5 text-left flex flex-col gap-1.5">
                <span className="text-xs font-extrabold text-purple-700 uppercase tracking-wide">Mutual Fund SIPs (Wealth Builder)</span>
                <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                  Start a Systematic Investment Plan (SIP) in Index or Large-Cap Funds from <strong className="text-slate-800">$10/month</strong> to build long-term compounding growth.
                </p>
              </div>
              <div className="bg-amber-50/40 rounded-2xl border border-amber-100/30 p-3.5 text-left flex flex-col gap-1.5">
                <span className="text-xs font-extrabold text-amber-700 uppercase tracking-wide">Government Savings Schemes</span>
                <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                  Invest in Public Provident Fund (PPF) or National Savings Certificates (NSC) offering sovereign-guaranteed <strong className="text-slate-800">7.1% - 7.7%</strong> tax-free returns.
                </p>
              </div>
            </div>
          </div>

          {/* Activity Timeline / AI suggestions box */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
            <h2 className="font-sans font-bold text-lg text-slate-800">Smart Budget suggestions</h2>
            <div className="bg-slate-50/70 rounded-2xl border border-slate-100/60 p-4 flex flex-col gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4.5 h-4.5 text-blue-600 animate-pulse" />
                <span className="text-xs font-bold text-blue-600 uppercase tracking-widest font-mono">INTELLIGENCE ACTION</span>
              </div>
              <p className="text-xs font-semibold text-slate-600 leading-relaxed text-left">
                Your food budget spent was higher early in the week. By reducing non-essential dining trips or grocery double-spends over the next 4 days, you will recover {formatCurrency(45)} of surplus!
              </p>
              <button 
                id="dash-chat-suggest-btn"
                onClick={() => navigate('/ai-chat')}
                className="text-xs font-bold text-blue-600 hover:underline text-left mt-1 self-start flex items-center gap-1 cursor-pointer"
              >
                <span>Ask AI Chat assistant</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Notifications panel */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <h2 className="font-sans font-bold text-lg text-slate-800">Alert Center</h2>
              <span className="px-2 py-0.5 text-[10px] font-extrabold bg-red-100 text-red-600 rounded-full">
                {notifications.filter(n => !n.read).length} Unread
              </span>
            </div>

            <div className="flex flex-col gap-3">
              {notifications.slice(0, 3).map((n) => (
                <div key={n.id} className="p-3.5 bg-slate-50/40 border border-slate-100/50 rounded-2xl flex flex-col gap-1 text-left">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-extrabold text-blue-600 uppercase tracking-wide">{n.category} alert</span>
                    <span className="text-[10px] font-mono text-slate-400">{n.timestamp}</span>
                  </div>
                  <p className="text-xs font-bold text-slate-800 line-clamp-1">{n.title}</p>
                  <p className="text-[11px] font-semibold text-slate-400 line-clamp-2">{n.description}</p>
                </div>
              ))}
            </div>

            <button 
              id="dash-view-all-alerts-btn"
              onClick={() => navigate('/notifications')}
              className="text-xs font-bold text-blue-600 hover:underline text-center"
            >
              See all notifications
            </button>
          </div>
        </div>
      </div>

      {/* --- Working Modal: Add Transaction --- */}
      {isAddTxOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl w-full max-w-md text-left flex flex-col gap-5">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-sans font-bold text-lg text-slate-800">Add Transaction Record</h3>
              <button 
                id="modal-close-add-tx-btn"
                onClick={() => setIsAddTxOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleAddTxSubmit} className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  id="modal-tx-type-expense-btn"
                  onClick={() => setTxType('expense')}
                  className={`py-2 text-xs font-bold rounded-lg transition-all ${txType === 'expense' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Expense
                </button>
                <button
                  type="button"
                  id="modal-tx-type-income-btn"
                  onClick={() => setTxType('income')}
                  className={`py-2 text-xs font-bold rounded-lg transition-all ${txType === 'income' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Income
                </button>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Merchant / Source Name</label>
                <input 
                  type="text" 
                  placeholder="e.g. Starbucks, Amazon, salary deposit" 
                  required 
                  value={txMerchant}
                  onChange={(e) => setTxMerchant(e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Amount ({profile.currency})</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="24.50" 
                    required 
                    value={txAmount}
                    onChange={(e) => setTxAmount(e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Payment Method</label>
                  <select 
                    value={txMethod}
                    onChange={(e) => setTxMethod(e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 bg-white"
                  >
                    <option value="Credit Card">Credit Card</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="Apple Pay">Apple Pay</option>
                    <option value="Google Wallet">Google Wallet</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Category</label>
                  <select 
                    value={txCategory}
                    onChange={(e) => setTxCategory(e.target.value)}
                    disabled={txType === 'income'}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 bg-white disabled:opacity-50"
                  >
                    {budgets.map(b => (
                      <option key={b.id} value={b.name}>{b.name}</option>
                    ))}
                    <option value="Investment">Investment</option>
                    <option value="Salary">Salary</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Date</label>
                  <input 
                    type="date" 
                    required 
                    value={txDate}
                    onChange={(e) => setTxDate(e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 bg-white"
                  />
                </div>
              </div>

              <button 
                type="submit"
                id="modal-tx-submit-btn"
                className="py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-sans font-bold text-sm tracking-wide rounded-xl shadow-md transition-all active:scale-98 text-center cursor-pointer mt-2"
              >
                Log Transaction Record
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- Working Modal: Scan Receipt --- */}
      {isScanReceiptOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl w-full max-w-md text-left flex flex-col gap-5">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-sans font-bold text-lg text-slate-800">Scan Physical Receipt</h3>
              <button 
                id="modal-close-scan-receipt-btn"
                onClick={() => setIsScanReceiptOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <p className="text-xs font-semibold text-slate-500 leading-relaxed">
              Upload a snapshot of your paper or digital invoice. The intelligent document scanner processes the OCR and automatically extracts transaction fields securely.
            </p>

            <div className="flex flex-col gap-4">
              <div className="border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center text-center bg-slate-50 relative hover:bg-slate-100 transition-colors">
                <input 
                  type="file" 
                  accept="image/*"
                  onChange={handleReceiptUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <FileText className="w-10 h-10 text-slate-400 mb-2 animate-bounce-slow" />
                <span className="text-sm font-bold text-slate-700">Choose Image or Snapshot</span>
                <span className="text-[10px] font-semibold text-slate-400 uppercase mt-1">Supports PNG, JPG, PDF • Max 10MB</span>
              </div>

              {scanning && (
                <div className="flex items-center justify-center gap-2.5 p-3.5 bg-blue-50 border border-blue-100 rounded-xl">
                  <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-xs font-bold text-blue-700">Intelligent Document Scanning...</span>
                </div>
              )}

              {scannedResult && (
                <div className="p-4 bg-teal-50 border border-teal-100 rounded-2xl flex flex-col gap-3 text-left">
                  <div className="flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-teal-600 stroke-[3]" />
                    <span className="text-xs font-bold text-teal-700 uppercase tracking-widest font-mono">Receipt Extracted Successfully!</span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm font-semibold text-slate-700">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Merchant</p>
                      <p className="text-slate-800 font-bold">{scannedResult.merchant}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Extracted Amount</p>
                      <p className="text-slate-800 font-bold">{formatCurrency(scannedResult.amount)}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Auto Category Tag</p>
                      <p className="text-slate-800 font-bold">{scannedResult.category}</p>
                    </div>
                  </div>
                  <button 
                    id="modal-scan-apply-btn"
                    onClick={applyScannedReceipt}
                    className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-sans font-bold text-xs tracking-wider rounded-xl transition-all text-center mt-1 cursor-pointer"
                  >
                    Confirm & Add to Ledger
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { 
  PieChart as ChartIcon, 
  ArrowUpRight, 
  Sparkles, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip 
} from 'recharts';

export default function BudgetPlannerPage() {
  const { budgets, updateBudgetLimit, transactions, profile, formatCurrency } = useFinance();

  // Monthly Income Input State
  const [monthlyIncome, setMonthlyIncome] = useState(5200);

  // Compute stats dynamically from state
  const totalLimit = budgets.reduce((sum, b) => sum + b.limit, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);
  const remainingBudget = Math.max(0, totalLimit - totalSpent);
  
  // Dynamic budget health score formula
  const overspentCategories = budgets.filter(b => b.spent > b.limit).length;
  const utilizationRatio = totalSpent / (totalLimit || 1);
  
  let healthScore = 100 - (overspentCategories * 20);
  if (utilizationRatio > 0.9) healthScore -= 30;
  else if (utilizationRatio > 0.7) healthScore -= 15;
  else if (utilizationRatio < 0.5) healthScore += 5;
  healthScore = Math.max(10, Math.min(100, healthScore));

  // Dynamic Savings Projections Chart Data
  // Projected savings = Income - total limit (representing budgeted savings)
  const monthlySavingsBuffer = Math.max(0, monthlyIncome - totalLimit);
  const savingsProjectionData = [
    { month: 'Current', savings: monthlySavingsBuffer },
    { month: 'Aug 26', savings: monthlySavingsBuffer * 2 },
    { month: 'Sep 26', savings: monthlySavingsBuffer * 3 },
    { month: 'Oct 26', savings: monthlySavingsBuffer * 4 },
    { month: 'Nov 26', savings: monthlySavingsBuffer * 5 },
    { month: 'Dec 26', savings: monthlySavingsBuffer * 6 }
  ];

  const handleIncomeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setMonthlyIncome(isNaN(val) ? 0 : val);
  };

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col lg:flex-row gap-8">
      
      {/* Left Budget Configurator */}
      <div className="flex-1 bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-6">
        <div>
          <h1 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight">Budget Allocation Planner</h1>
          <p className="font-sans text-xs font-semibold text-slate-400 mt-1">Configure allocation bounds with real-time health updates</p>
        </div>

        {/* Income config card */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="text-left">
            <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Adjust Income Stream</p>
            <p className="text-sm font-extrabold text-slate-700 mt-0.5">Est. Monthly Disposable Earnings</p>
          </div>
          <div className="relative w-full sm:w-48">
            <div className="absolute left-3.5 top-3.5 text-xs font-black text-slate-400">
              {profile.currency}
            </div>
            <input
              type="number"
              value={monthlyIncome}
              onChange={handleIncomeChange}
              className="w-full pl-8 pr-4 py-3 border border-slate-200 bg-white rounded-xl text-sm font-bold text-slate-800 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* List of categories with RANGE SLIDERS */}
        <div className="flex flex-col gap-5">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Allocation Bounds Sliders</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {budgets.map((b) => {
              const isOver = b.spent > b.limit;
              const ratio = Math.min(100, (b.spent / (b.limit || 1)) * 100);

              return (
                <div key={b.id} className="p-4 border border-slate-100/75 bg-slate-50/30 rounded-2xl flex flex-col gap-3 text-left">
                  <div className="flex justify-between items-center text-xs font-bold">
                    <span className="text-slate-700 flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: b.color }}></span>
                      {b.name}
                    </span>
                    <span className={`font-mono ${isOver ? 'text-red-500' : 'text-slate-500'}`}>
                      Limit: {formatCurrency(b.limit)}
                    </span>
                  </div>

                  {/* Range slider input connected to updateBudgetLimit */}
                  <input
                    type="range"
                    min="100"
                    max="2000"
                    step="50"
                    value={b.limit}
                    onChange={(e) => updateBudgetLimit(b.id, parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600 focus:outline-none"
                  />

                  <div className="flex justify-between items-center text-[10px] font-semibold text-slate-400">
                    <span>Spent: {formatCurrency(b.spent)} ({ratio.toFixed(0)}%)</span>
                    <span>Slider range: {formatCurrency(100)} - {formatCurrency(2000)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Smart Suggestions card */}
        <div className="bg-blue-50/30 border border-blue-100/25 p-5 rounded-[24px] flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4.5 h-4.5 text-blue-600 animate-pulse" />
            <span className="text-xs font-mono font-bold text-blue-600 uppercase tracking-widest">Budget Optimization Suggestion</span>
          </div>
          <p className="text-xs font-semibold text-slate-600 leading-relaxed text-left">
            By shifting $150 from your Transport budget bounds to your Shopping allocation, you can accommodate your high shopping spends while raising your Budget Health score to <strong>96%</strong>.
          </p>
        </div>

      </div>

      {/* Right Stats & Projections panel */}
      <div className="w-full lg:w-96 flex flex-col gap-8 shrink-0 text-left">
        
        {/* Score & Visualization */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Health Assessment</p>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Budget Health Score</p>
              <p className="text-4xl font-extrabold text-slate-800 tracking-tight mt-1">{healthScore}/100</p>
            </div>
            <div className="w-14 h-14 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 font-bold text-lg border border-blue-100">
              {healthScore >= 90 ? 'A+' : healthScore >= 75 ? 'B' : 'C'}
            </div>
          </div>

          <div className="flex flex-col gap-2.5">
            <div className="flex justify-between text-xs font-bold text-slate-500">
              <span>Overall Bounds Utilization</span>
              <span>{((totalSpent / totalLimit) * 100).toFixed(0)}%</span>
            </div>
            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
              <div 
                className="bg-blue-600 h-full rounded-full transition-all" 
                style={{ width: `${Math.min(100, (totalSpent / totalLimit) * 100)}%` }}
              ></div>
            </div>
          </div>

          <div className="flex items-start gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-100/50">
            {healthScore >= 80 ? (
              <>
                <CheckCircle className="w-4.5 h-4.5 text-emerald-500 shrink-0 mt-0.5" />
                <p className="text-[11px] font-semibold text-slate-500 leading-relaxed">
                  Your budget allocations are safe and structurally balanced relative to your income. Keep it up!
                </p>
              </>
            ) : (
              <>
                <AlertCircle className="w-4.5 h-4.5 text-amber-500 shrink-0 mt-0.5" />
                <p className="text-[11px] font-semibold text-slate-500 leading-relaxed">
                  Budget allocations are slightly aggressive. Shift bounds upwards or reduce shopping ranges to balance.
                </p>
              </>
            )}
          </div>
        </div>

        {/* Dynamic Recharts Savings projections area */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
          <div>
            <h2 className="font-sans font-bold text-base text-slate-800">Savings Projection</h2>
            <p className="text-xs font-semibold text-slate-400 mt-0.5">Est. cumulative savings over 6 months</p>
          </div>

          {/* Area Chart visualization */}
          <div className="w-full h-44">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={savingsProjectionData}>
                <defs>
                  <linearGradient id="savingsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#94A3B8" fontSize={9} tickLine={false} axisLine={false} />
                <Tooltip formatter={(value) => [formatCurrency(Number(value)), 'Savings']} />
                <Area 
                  type="monotone" 
                  dataKey="savings" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#savingsGrad)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex justify-between items-center pt-2 border-t border-slate-100 text-xs font-bold">
            <span className="text-slate-400">Monthly Surplus Savings</span>
            <span className="text-emerald-600">{formatCurrency(monthlySavingsBuffer)} / mo</span>
          </div>
        </div>

      </div>

    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { useFinance } from '../context/FinanceContext';
import { 
  Mic, 
  Volume2, 
  Cpu, 
  Sparkles, 
  VolumeX, 
  Play, 
  Square,
  Globe,
  CornerDownRight,
  RefreshCw,
  Clock,
  MicOff
} from 'lucide-react';

export default function VoiceAssistantPage() {
  const { simulateVoiceInput, voiceLanguage, setVoiceLanguage } = useFinance();
  
  // Voice states: 'idle' | 'listening' | 'processing' | 'speaking'
  const [voiceState, setVoiceState] = useState<'idle' | 'listening' | 'processing' | 'speaking'>('idle');
  const [transcription, setTranscription] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [history, setHistory] = useState<{ query: string; reply: string; timestamp: string }[]>([
    { query: "How much spent on groceries?", reply: "You spent $172.70 on Food & Drinks this month. 71% of budget remaining.", timestamp: "10 minutes ago" }
  ]);

  // Audio waves simulator
  const [waveHeights, setWaveHeights] = useState<number[]>([15, 25, 45, 10, 30, 60, 20, 50, 40, 15]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (voiceState === 'listening') {
      interval = setInterval(() => {
        setWaveHeights(Array.from({ length: 12 }, () => Math.floor(Math.random() * 65) + 10));
      }, 100);
    } else {
      setWaveHeights([10, 15, 12, 10, 14, 12, 15, 10, 12, 10]);
    }
    return () => clearInterval(interval);
  }, [voiceState]);

  const startListening = () => {
    setVoiceState('listening');
    setTranscription('Listening... Speak now');
    setAiResponse('');
  };

  const stopListeningAndProcess = async (sampleQuery?: string) => {
    if (voiceState !== 'listening' && !sampleQuery) return;
    
    setVoiceState('processing');
    setTranscription('Decoding speech via secure voice processor...');

    // Select a query: either the click-triggered sample or a default
    const query = sampleQuery || (voiceLanguage === 'en' 
      ? 'Can I save more this month?' 
      : 'क्या मैं इस महीने अधिक बचत कर सकता हूँ?');

    // Simulated decoding delay
    await new Promise((resolve) => setTimeout(resolve, 1400));
    setTranscription(`"${query}"`);

    // Simulated Phi-3 reasoning delay
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    // Get real computed answer from Context generator
    const aiMsg = await simulateVoiceInput(query);
    
    setVoiceState('speaking');
    setAiResponse(aiMsg.text);

    // Speak aloud!
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(aiMsg.text);
    utterance.onend = () => {
      setVoiceState('idle');
    };
    utterance.onerror = () => {
      setVoiceState('idle');
    };
    window.speechSynthesis.speak(utterance);

    // Log history
    setHistory((prev) => [
      { query, reply: aiMsg.text, timestamp: 'Just now' },
      ...prev
    ]);
  };

  const cancelVoice = () => {
    window.speechSynthesis.cancel();
    setVoiceState('idle');
    setTranscription('');
    setAiResponse('');
  };

  // Sample english and hindi voice inputs
  const englishSamples = [
    "Where did I overspend?",
    "Can I save more this month?",
    "What are my recurring expenses?"
  ];

  const hindiSamples = [
    "मैंने कहाँ अधिक खर्च किया?",
    "क्या मैं अधिक बचत कर सकता हूँ?",
    "मेरे आवर्ती खर्च क्या हैं?"
  ];

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col lg:flex-row gap-8">
      
      {/* Left Assistant Panel */}
      <div className="flex-1 bg-white border border-slate-100 p-8 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col items-center justify-center text-center gap-8 relative overflow-hidden">
        
        {/* Secure watermark */}
        <div className="absolute top-6 left-6 flex items-center gap-1.5 bg-slate-50 border border-slate-100 px-3 py-1 rounded-lg">
          <Cpu className="w-4 h-4 text-teal-600 animate-spin-slow" />
          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Secure Voice Assistant</span>
        </div>

        {/* Language selector */}
        <div className="absolute top-6 right-6 flex items-center gap-2">
          <Globe className="w-4 h-4 text-slate-400" />
          <select
            value={voiceLanguage}
            onChange={(e) => setVoiceLanguage(e.target.value as 'en' | 'hi')}
            className="p-1.5 border border-slate-100 bg-slate-50 rounded-lg text-xs font-bold text-slate-600 focus:outline-none"
          >
            <option value="en">English (US)</option>
            <option value="hi">Hindi (भारत)</option>
          </select>
        </div>

        {/* State Indicators */}
        <div className="mt-8 flex flex-col gap-1.5 items-center">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
            voiceState === 'listening' ? 'bg-red-50 border border-red-100 text-red-600' :
            voiceState === 'processing' ? 'bg-blue-50 border border-blue-100 text-blue-600' :
            voiceState === 'speaking' ? 'bg-emerald-50 border border-emerald-100 text-emerald-600' :
            'bg-slate-50 border border-slate-100 text-slate-500'
          }`}>
            <span className={`w-2 h-2 rounded-full ${
              voiceState === 'listening' ? 'bg-red-500 animate-ping' :
              voiceState === 'processing' ? 'bg-blue-500 animate-spin' :
              voiceState === 'speaking' ? 'bg-emerald-500 animate-pulse' :
              'bg-slate-400'
            }`}></span>
            <span>{voiceState.toUpperCase()}</span>
          </span>
          <p className="text-xs font-semibold text-slate-400 mt-1">
            {voiceState === 'idle' && "Ready to process your financial voice command"}
            {voiceState === 'listening' && "Say your budget query aloud now"}
            {voiceState === 'processing' && "Processing speech input..."}
            {voiceState === 'speaking' && "Synthesizing dynamic vocal response"}
          </p>
        </div>

        {/* Animated Waveform indicator */}
        <div className="flex items-end justify-center gap-1.5 h-20 w-full max-w-xs px-6">
          {waveHeights.map((h, i) => (
            <div 
              key={i} 
              className={`w-2 rounded-full transition-all duration-100 ${
                voiceState === 'listening' ? 'bg-red-500' :
                voiceState === 'processing' ? 'bg-blue-500' :
                voiceState === 'speaking' ? 'bg-emerald-500' :
                'bg-slate-200'
              }`}
              style={{ height: `${h}%` }}
            ></div>
          ))}
        </div>

        {/* Large Animated Microphone Trigger */}
        <div className="relative">
          <div className={`absolute -inset-4 rounded-full blur-xl opacity-20 transition-all ${
            voiceState === 'listening' ? 'bg-red-500 scale-125' :
            voiceState === 'processing' ? 'bg-blue-500 scale-110' :
            voiceState === 'speaking' ? 'bg-emerald-500 scale-115' :
            'bg-transparent scale-100'
          }`}></div>

          <button
            id="voice-mic-main-btn"
            onClick={voiceState === 'listening' ? () => stopListeningAndProcess() : startListening}
            className={`w-28 h-28 rounded-full border flex items-center justify-center shadow-lg cursor-pointer transition-all ${
              voiceState === 'listening' ? 'bg-red-500 border-red-600 text-white hover:bg-red-600 hover:scale-105 active:scale-95' :
              voiceState === 'processing' ? 'bg-blue-600 border-blue-700 text-white cursor-wait animate-pulse' :
              voiceState === 'speaking' ? 'bg-emerald-500 border-emerald-600 text-white hover:bg-emerald-600 hover:scale-105' :
              'bg-blue-600 border-blue-700 text-white hover:bg-blue-700 hover:scale-105 active:scale-95'
            }`}
          >
            {voiceState === 'processing' ? (
              <RefreshCw className="w-12 h-12 animate-spin" />
            ) : (
              <Mic className="w-12 h-12" />
            )}
          </button>
        </div>

        {/* Large Buttons row */}
        <div className="flex items-center gap-4">
          {voiceState === 'listening' ? (
            <button
              id="voice-stop-btn"
              onClick={() => stopListeningAndProcess()}
              className="px-6 py-3 border border-red-100 bg-red-50 text-red-600 font-sans font-bold text-sm tracking-wide rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              <Square className="w-4 h-4 fill-red-600" />
              <span>Stop & Process</span>
            </button>
          ) : voiceState !== 'idle' ? (
            <button
              id="voice-cancel-btn"
              onClick={cancelVoice}
              className="px-6 py-3 border border-slate-200 bg-white text-slate-600 font-sans font-bold text-sm tracking-wide rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              <Square className="w-4 h-4" />
              <span>Stop Speech</span>
            </button>
          ) : (
            <button
              id="voice-push-talk-btn"
              onClick={startListening}
              className="px-8 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-sans font-bold text-sm tracking-wider rounded-xl shadow-md transition-all flex items-center gap-2.5 cursor-pointer active:scale-95"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Push to Talk</span>
            </button>
          )}
        </div>

        {/* Transcription Area Box */}
        <div className="w-full max-w-md bg-slate-50/70 border border-slate-100/60 p-5 rounded-2xl flex flex-col gap-2.5 text-left min-h-24">
          <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Transcription Feed</p>
          <p className="text-sm font-bold text-slate-700">
            {transcription || "No speech detected. Press the microphone to talk..."}
          </p>
          {aiResponse && (
            <div className="mt-3 pt-3 border-t border-slate-200/50 flex flex-col gap-1.5 text-left">
              <span className="text-[10px] font-mono font-bold text-teal-600 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-teal-500 fill-teal-500" />
                <span>Smart Voice Assistant Response</span>
              </span>
              <p className="text-xs font-semibold text-slate-600 leading-relaxed">
                {aiResponse}
              </p>
            </div>
          )}
        </div>

      </div>

      {/* Right Samples & History Panel */}
      <div className="w-full lg:w-96 flex flex-col gap-8 shrink-0">
        
        {/* Click to Speak Verbal Samples */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-600" />
            <h2 className="font-sans font-bold text-base text-slate-800">Verbal Simulation Commands</h2>
          </div>
          <p className="text-xs font-semibold text-slate-400">
            Select a sample query to quickly test voice assistant outputs:
          </p>

          <div className="flex flex-col gap-2">
            {voiceLanguage === 'en' ? (
              englishSamples.map((sample, idx) => (
                <button
                  key={idx}
                  id={`voice-sample-en-${idx}`}
                  onClick={() => stopListeningAndProcess(sample)}
                  disabled={voiceState !== 'idle'}
                  className="w-full text-left p-3 border border-slate-50 hover:border-blue-100 hover:bg-blue-50/20 text-xs font-bold rounded-xl cursor-pointer transition-all text-slate-600 flex items-center gap-2 group"
                >
                  <CornerDownRight className="w-3.5 h-3.5 text-blue-500 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                  <span className="truncate">"{sample}"</span>
                </button>
              ))
            ) : (
              hindiSamples.map((sample, idx) => (
                <button
                  key={idx}
                  id={`voice-sample-hi-${idx}`}
                  onClick={() => stopListeningAndProcess(sample)}
                  disabled={voiceState !== 'idle'}
                  className="w-full text-left p-3 border border-slate-50 hover:border-blue-100 hover:bg-blue-50/20 text-xs font-bold rounded-xl cursor-pointer transition-all text-slate-600 flex items-center gap-2 group"
                >
                  <CornerDownRight className="w-3.5 h-3.5 text-blue-500 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                  <span className="truncate">"{sample}"</span>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Local Conversation history */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-slate-500" />
            <h2 className="font-sans font-bold text-base text-slate-800">Local Vocal History</h2>
          </div>

          <div className="flex flex-col gap-4">
            {history.map((h, i) => (
              <div key={i} className="border-b border-slate-100 pb-3 last:border-0 last:pb-0 text-left flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span className="font-bold">SPEECH TRANSCRIPT</span>
                  <span>{h.timestamp}</span>
                </div>
                <p className="text-xs font-extrabold text-slate-700">"{h.query}"</p>
                <div className="p-2.5 bg-slate-50 border border-slate-100/50 rounded-lg">
                  <p className="text-[11px] font-semibold text-slate-500 leading-relaxed">{h.reply}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}

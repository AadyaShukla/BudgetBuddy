import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { 
  Bell, 
  Check, 
  Trash2, 
  AlertTriangle, 
  Sparkles, 
  DollarSign, 
  Smartphone,
  CheckCircle,
  Inbox
} from 'lucide-react';

export default function NotificationsPage() {
  const { 
    notifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead 
  } = useFinance();

  const [filterType, setFilterType] = useState<'All' | 'budget' | 'emi' | 'transaction' | 'system'>('All');

  // Filter alerts
  const filteredNotifs = notifications.filter((n) => {
    return filterType === 'All' || n.category === filterType;
  });

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'budget': return 'bg-rose-50 border-rose-100 text-rose-600';
      case 'emi': return 'bg-amber-50 border-amber-100 text-amber-600';
      case 'transaction': return 'bg-blue-50 border-blue-100 text-blue-600';
      case 'system': return 'bg-teal-50 border-teal-100 text-teal-600';
      default: return 'bg-slate-50 border-slate-100 text-slate-500';
    }
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'budget': return AlertTriangle;
      case 'emi': return DollarSign;
      case 'transaction': return Smartphone;
      case 'system': return Sparkles;
      default: return Bell;
    }
  };

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col h-screen max-h-screen">
      
      {/* Top action bar */}
      <header className="flex items-center justify-between border-b border-slate-100 pb-5 shrink-0">
        <div>
          <h1 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight">Notification Center</h1>
          <p className="font-sans text-xs font-semibold text-slate-400 mt-1">Real-time notification feeds to keep your finances in track</p>
        </div>

        <button
          id="notif-mark-all-read-btn"
          onClick={markAllNotificationsAsRead}
          className="px-4 py-2 border border-slate-200 hover:border-blue-100 text-slate-600 hover:text-blue-600 hover:bg-blue-50/20 bg-white font-sans font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
        >
          <Check className="w-4 h-4 stroke-[3]" />
          <span>Mark All Read</span>
        </button>
      </header>

      {/* Categories Filter Pills */}
      <section className="flex flex-wrap gap-2 py-4 shrink-0">
        {[
          { label: 'All Alerts', val: 'All' },
          { label: 'Budget Alerts', val: 'budget' },
          { label: 'EMI Reminders', val: 'emi' },
          { label: 'Transactions', val: 'transaction' },
          { label: 'AI Suggestions', val: 'system' }
        ].map((pill) => (
          <button
            key={pill.val}
            onClick={() => setFilterType(pill.val as any)}
            className={`px-4 py-1.5 text-xs font-bold rounded-full transition-all cursor-pointer ${
              filterType === pill.val 
                ? 'bg-blue-600 text-white shadow-sm' 
                : 'bg-white border border-slate-100 hover:bg-slate-50 text-slate-500'
            }`}
          >
            {pill.label}
          </button>
        ))}
      </section>

      {/* Notifications scroll thread */}
      <section className="flex-1 overflow-y-auto pr-2 pb-6 space-y-3 scrollbar-thin">
        {filteredNotifs.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center py-20 bg-white border border-slate-100 rounded-[24px] p-8 max-w-md mx-auto my-12 shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)]">
            <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-4 border border-blue-100">
              <Inbox className="w-8 h-8" />
            </div>
            <h3 className="font-sans font-bold text-lg text-slate-800">All caught up!</h3>
            <p className="text-xs font-semibold text-slate-400 mt-1 max-w-xs">
              No notifications matching your filter category are unread. Outstanding jobs!
            </p>
          </div>
        ) : (
          filteredNotifs.map((notif) => {
            const IconComponent = getCategoryIcon(notif.category);
            return (
              <div 
                key={notif.id}
                id={`notif-card-${notif.id}`}
                className={`p-4 border rounded-2xl flex items-start gap-4 transition-all relative group ${
                  notif.read 
                    ? 'bg-white border-slate-100 opacity-65' 
                    : 'bg-white border-blue-100 shadow-sm shadow-blue-50/40'
                }`}
              >
                {/* Category Icon */}
                <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${getCategoryColor(notif.category)}`}>
                  <IconComponent className="w-5 h-5 stroke-[2.5]" />
                </div>

                {/* Text Body */}
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[9px] font-mono font-bold uppercase tracking-wider text-slate-400">
                      {notif.category} Channel
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">{notif.timestamp}</span>
                  </div>
                  <h4 className="text-sm font-extrabold text-slate-800">{notif.title}</h4>
                  <p className="text-xs font-semibold text-slate-500 mt-1 leading-relaxed">{notif.description}</p>
                </div>

                {/* Mark as read tick (Only if unread) */}
                {!notif.read && (
                  <button
                    id={`notif-read-btn-${notif.id}`}
                    onClick={() => markNotificationAsRead(notif.id)}
                    className="p-1.5 border border-slate-200 hover:border-blue-200 hover:bg-blue-50 text-slate-400 hover:text-blue-600 rounded-lg transition-all cursor-pointer shadow-sm active:scale-95"
                    title="Mark as read"
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </button>
                )}
              </div>
            );
          })
        )}
      </section>

    </div>
  );
}

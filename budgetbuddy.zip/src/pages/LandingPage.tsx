import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  Mic, 
  PieChart, 
  Sparkles, 
  TrendingUp, 
  Bell, 
  ArrowRight,
  TrendingDown,
  CheckCircle,
  HelpCircle,
  MessageSquare,
  Globe,
  Coins,
  CreditCard,
  Landmark,
  FileText,
  Eye,
  Languages,
  Smartphone
} from 'lucide-react';
import Navbar from '../components/Navbar';
import { motion } from 'motion/react';

export default function LandingPage() {
  const navigate = useNavigate();
  const [formSubmitted, setFormSubmitted] = useState(false);

  const features = [
    {
      title: 'Expense Tracking',
      description: 'Automatically organize and monitor your daily spending.',
      icon: Coins,
      color: 'bg-blue-500/10 text-blue-600 border-blue-500/20'
    },
    {
      title: 'Smart Budget Planning',
      description: 'Create monthly budgets and stay on track with visual progress.',
      icon: PieChart,
      color: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
    },
    {
      title: 'AI Financial Assistant',
      description: 'Ask questions about your spending in natural language.',
      icon: Sparkles,
      color: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20'
    },
    {
      title: 'Voice Assistant',
      description: 'Talk to your finances in English or Hindi using voice commands.',
      icon: Mic,
      color: 'bg-amber-500/10 text-amber-600 border-amber-500/20'
    },
    {
      title: 'Automatic Expense Categorization',
      description: 'Transactions are intelligently organized into categories like Food, Shopping, Bills, Travel, Healthcare, Entertainment, and more.',
      icon: CreditCard,
      color: 'bg-rose-500/10 text-rose-600 border-rose-500/20'
    },
    {
      title: 'UPI & SMS Transaction Tracking',
      description: 'View all your spending from supported payment notifications and SMS in one timeline.',
      icon: Smartphone,
      color: 'bg-purple-500/10 text-purple-600 border-purple-500/20'
    },
    {
      title: 'Spending Insights',
      description: 'Understand where your money goes with charts and trends.',
      icon: TrendingUp,
      color: 'bg-teal-500/10 text-teal-600 border-teal-500/20'
    },
    {
      title: 'Bill & EMI Reminders',
      description: 'Never miss upcoming payments.',
      icon: Bell,
      color: 'bg-orange-500/10 text-orange-600 border-orange-500/20'
    },
    {
      title: 'Overspending Alerts',
      description: 'Receive timely alerts before exceeding your planned budget.',
      icon: TrendingDown,
      color: 'bg-red-500/10 text-red-600 border-red-500/20'
    },
    {
      title: 'Savings Opportunities',
      description: 'Discover practical ways to save more every month.',
      icon: ShieldCheck,
      color: 'bg-green-500/10 text-green-600 border-green-500/20'
    },
    {
      title: 'Investment Suggestions',
      description: 'Receive educational suggestions for options such as SIPs, Fixed Deposits, and emergency savings based on your spending habits.',
      icon: Landmark,
      color: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20'
    },
    {
      title: 'Financial Health Score',
      description: 'Track your overall financial wellness with an easy-to-understand score.',
      icon: HeartHandshakeIcon,
      color: 'bg-pink-500/10 text-pink-600 border-pink-500/20'
    },
    {
      title: 'Monthly Reports',
      description: 'Review spending summaries and financial trends.',
      icon: FileText,
      color: 'bg-slate-500/10 text-slate-600 border-slate-500/20'
    },
    {
      title: 'Multilingual Experience',
      description: 'Use the application comfortably in English or Hindi.',
      icon: Languages,
      color: 'bg-violet-500/10 text-violet-600 border-violet-500/20'
    },
    {
      title: 'Privacy First',
      description: 'Your financial information stays secure and under your control.',
      icon: Eye,
      color: 'bg-sky-500/10 text-sky-600 border-sky-500/20'
    }
  ];

  function HeartHandshakeIcon(props: React.SVGProps<SVGSVGElement>) {
    return (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        {...props}
      >
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
        <path d="M12 5 9.04 7.96a2.17 2.17 0 0 0 0 3.08v0c.82.82 2.13.85 3 .07l2.07-1.9a2.82 2.82 0 0 1 3.79-.18l2.96 2.24" />
        <path d="m18 15-2-2" />
        <path d="m15 18-2-2" />
      </svg>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-24 px-6 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-7 flex flex-col gap-6 text-left">
          <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-100 text-blue-700 font-sans font-bold text-xs uppercase tracking-widest px-3.5 py-1.5 rounded-full w-fit">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Secure & Personal Wealth Companion</span>
          </div>
          
          <h1 className="font-sans font-extrabold text-4xl sm:text-5xl lg:text-6xl tracking-tight text-slate-900 leading-tight animate-fade-in">
            Your Smart Personal <br/>
            <span className="text-blue-600 bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">Finance Companion</span>
          </h1>

          <p className="font-sans font-medium text-lg text-slate-500 max-w-xl leading-relaxed">
            Track every expense, build better budgets, receive personalized financial insights, manage bills, and interact with your finances naturally through voice—all while keeping your personal data private.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-4">
            <button
              id="landing-get-started-btn"
              onClick={() => navigate('/dashboard')}
              className="px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-sans font-bold text-sm tracking-wide rounded-xl shadow-lg shadow-blue-100 flex items-center gap-2 transition-all active:scale-95 group cursor-pointer"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <a
              id="landing-learn-more-btn"
              href="#features"
              className="px-6 py-3.5 border border-slate-200 hover:border-slate-300 bg-white text-slate-700 font-sans font-bold text-sm tracking-wide rounded-xl shadow-sm hover:bg-slate-50/50 transition-all active:scale-95 cursor-pointer"
            >
              Learn More
            </a>
          </div>
        </div>

        {/* Hero Interactive UI Mockup */}
        <div className="lg:col-span-5 relative">
          <div className="absolute -inset-2 bg-gradient-to-r from-blue-500 to-teal-500 rounded-3xl blur-2xl opacity-10 animate-pulse-slow"></div>
          
          <div className="relative bg-white border border-slate-100 rounded-[24px] p-6 shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5">
            {/* Mock Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-400"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                <div className="w-3 h-3 rounded-full bg-green-400"></div>
              </div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">BudgetBuddy Premium Ledger</span>
            </div>

            {/* Simulated Balance */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Remaining Budget</p>
                <p className="text-3xl font-extrabold text-slate-800 tracking-tight">$3,124.50</p>
              </div>
              <div className="text-right">
                <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 px-2 py-1 rounded-lg text-xs font-bold border border-emerald-100">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>94% Health</span>
                </span>
              </div>
            </div>

            {/* Interactive Progress Bar */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-xs font-bold text-slate-500">
                <span>Total Spent ($1,875.50)</span>
                <span>Limit ($5,000.00)</span>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden flex">
                <div className="bg-blue-600 h-full rounded-full" style={{ width: '37.5%' }}></div>
              </div>
            </div>

            {/* Simulated Recent Transactions list */}
            <div className="flex flex-col gap-2.5">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider text-left">Auto-Categorized Transactions</p>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-teal-50 text-teal-600 border border-teal-100 rounded-xl flex items-center justify-center font-bold text-sm">🍱</div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-slate-800">Whole Foods Market</p>
                    <p className="text-[10px] font-semibold text-slate-400">Food & Drinks • Auto-Categorized</p>
                  </div>
                </div>
                <span className="text-sm font-bold text-red-600">-$154.20</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-blue-50 text-blue-600 border border-blue-100 rounded-xl flex items-center justify-center font-bold text-sm">💻</div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-slate-800">Apex Corp Salary</p>
                    <p className="text-[10px] font-semibold text-slate-400">Income • Direct Deposit</p>
                  </div>
                </div>
                <span className="text-sm font-bold text-emerald-600">+$5,200.00</span>
              </div>
            </div>
            
            {/* private computation footnote */}
            <p className="text-[10px] font-mono font-medium text-slate-400 text-center">
              🛡️ End-to-end secure asset protection
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto flex flex-col gap-4 mb-16">
            <span className="text-xs font-bold text-teal-600 uppercase tracking-widest bg-teal-50 border border-teal-100 px-3 py-1 rounded-full w-fit mx-auto">Private Financial Intelligence</span>
            <h2 className="font-sans font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight">
              Designed For High-Performance Security
            </h2>
            <p className="font-sans text-slate-500 font-medium">
              We leverage advanced analytical models to process transactions, speech transcription, and budget projection models completely securely. Your financial statements stay in your own hands.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feat, idx) => {
              const IconComp = feat.icon;
              return (
                <div 
                  key={idx}
                  className="bg-slate-50/50 hover:bg-white border border-slate-100 hover:border-slate-200 hover:shadow-xl hover:shadow-slate-100/60 transition-all duration-300 p-6 rounded-2xl flex flex-col text-left gap-4"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${feat.color}`}>
                    <IconComp className="w-6 h-6" />
                  </div>
                  <h3 className="font-sans font-bold text-lg text-slate-800">{feat.title}</h3>
                  <p className="font-sans text-sm text-slate-500 leading-relaxed font-medium">{feat.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-slate-50 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 text-left flex flex-col gap-5">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-widest">Private Sovereign Finance</span>
            <h2 className="font-sans font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight">
              Reinventing Personal Budgets with Clean Analytics
            </h2>
            <p className="font-sans text-slate-500 font-medium leading-relaxed">
              Standard budgeting apps sell your spending trends to marketing agencies and clutter your interface with unnecessary ads.
            </p>
            <p className="font-sans text-slate-500 font-medium leading-relaxed">
              BudgetBuddy is designed as a <strong>premium, ad-free financial companion</strong>. Experience conversational finance with instantaneous feedback, detailed tracking, and complete privacy controls, allowing you to stay in absolute control of your capital.
            </p>
            
            <div className="flex flex-col gap-3 pt-2">
              <div className="flex items-center gap-3 text-slate-700">
                <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="font-sans text-sm font-semibold">Instant, secure AI querying options</span>
              </div>
              <div className="flex items-center gap-3 text-slate-700">
                <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="font-sans text-sm font-semibold">Zero hidden broker fees, transparent metrics</span>
              </div>
              <div className="flex items-center gap-3 text-slate-700">
                <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />
                <span className="font-sans text-sm font-semibold">Multi-device layout perfectly optimized</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border border-slate-800 p-8 rounded-[24px] text-white shadow-xl relative overflow-hidden flex flex-col justify-center min-h-[320px]">
            <div className="absolute -right-16 -bottom-16 w-48 h-48 bg-teal-500 rounded-full blur-3xl opacity-20 pointer-events-none"></div>
            <div className="absolute -left-16 -top-16 w-48 h-48 bg-blue-500 rounded-full blur-3xl opacity-15 pointer-events-none"></div>

            <div className="relative z-10 text-left flex flex-col gap-6">
              <span className="text-xs font-bold text-teal-400 font-mono tracking-widest uppercase">Wisdom of the Ledger</span>
              
              <div className="flex flex-col gap-4">
                <p className="font-serif italic text-xl sm:text-2xl text-slate-100 leading-relaxed font-semibold">
                  "Do not save what is left after spending, but spend what is left after saving."
                </p>
                <div className="flex items-center gap-3 mt-2">
                  <div className="w-8 h-0.5 bg-blue-500"></div>
                  <span className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400">Warren Buffett</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-6 max-w-4xl text-center flex flex-col gap-8">
          <div className="flex flex-col gap-4">
            <span className="text-xs font-bold text-teal-600 uppercase tracking-widest bg-teal-50 border border-teal-100 px-3 py-1 rounded-full w-fit mx-auto">Get in Touch</span>
            <h2 className="font-sans font-extrabold text-3xl sm:text-4xl text-slate-900 tracking-tight">We Love Customer Collaboration</h2>
            <p className="font-sans text-slate-500 font-medium max-w-xl mx-auto">
              Want to request features or customize BudgetBuddy for your organization? Send us a message securely.
            </p>
          </div>

          {formSubmitted ? (
            <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-[24px] text-center max-w-xl mx-auto flex flex-col gap-2.5">
              <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto animate-bounce" />
              <h3 className="font-sans font-bold text-lg text-emerald-800">Secure Message Dispatched!</h3>
              <p className="text-xs font-semibold text-emerald-600 leading-relaxed">
                Your communication has been processed securely. Zero external tracking data relays occurred during transport.
              </p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setFormSubmitted(true); }} className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto text-left">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Your Name</label>
                <input type="text" placeholder="Saraswati" required className="p-3 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-blue-500" />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Email Address</label>
                <input type="email" placeholder="user@example.com" required className="p-3 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-blue-500" />
              </div>
              <div className="flex flex-col gap-1.5 sm:col-span-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Inquiry Message</label>
                <textarea placeholder="Write your inquiry here..." required rows={3} className="p-3 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-blue-500 resize-none" />
              </div>
              <button type="submit" className="sm:col-span-2 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-sans font-bold text-sm tracking-wider rounded-xl transition-all active:scale-98 text-center cursor-pointer">
                Send Secure Message
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-100 bg-slate-50 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
              <Sparkles className="w-4.5 h-4.5" />
            </div>
            <span className="font-sans font-bold text-base text-slate-800">
              BudgetBuddy <span className="text-[10px] text-teal-600 font-mono tracking-widest font-bold uppercase ml-1">Secure Premium</span>
            </span>
          </div>
          <p className="text-xs font-semibold text-slate-400">
            © 2026 BudgetBuddy Project. All rights reserved. Operating securely.
          </p>
        </div>
      </footer>
    </div>
  );
}

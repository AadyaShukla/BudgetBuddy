import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFinance } from '../context/FinanceContext';
import { 
  Bot, 
  Mic, 
  Send, 
  Trash2, 
  Sparkles, 
  Copy, 
  Volume2, 
  ChevronDown, 
  ChevronUp, 
  Check, 
  VolumeX,
  Play,
  StopCircle
} from 'lucide-react';

export default function AIChatPage() {
  const navigate = useNavigate();
  const { chatMessages, sendMessage, clearChat, simulateVoiceInput } = useFinance();
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom whenever messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || sending) return;

    setSending(true);
    const textToSend = inputText;
    setInputText('');
    await sendMessage(textToSend);
    setSending(false);
  };

  const handleSuggestedPrompt = async (prompt: string) => {
    if (sending) return;
    setSending(true);
    await sendMessage(prompt);
    setSending(false);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    });
  };

  const handleSpeak = (id: string, text: string) => {
    if (speakingId === id) {
      // Stop current speaking
      window.speechSynthesis.cancel();
      setSpeakingId(null);
    } else {
      window.speechSynthesis.cancel(); // cancel current speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => {
        setSpeakingId(null);
      };
      utterance.onerror = () => {
        setSpeakingId(null);
      };
      setSpeakingId(id);
      window.speechSynthesis.speak(utterance);
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedId(prev => prev === id ? null : id);
  };

  const suggestedPrompts = [
    "Where did I overspend?",
    "Can I save more this month?",
    "What are my recurring expenses?"
  ];

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col h-screen max-h-screen">
      
      {/* Header Panel */}
      <header className="flex items-center justify-between border-b border-slate-100 pb-5 shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <Bot className="w-6 h-6 text-blue-600" />
            <h1 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight">AI Financial Assistant</h1>
          </div>
          <p className="font-sans text-xs font-semibold text-slate-400 mt-1 flex items-center gap-1.5">
            <span>Powered by Secure Analytical Processing Model</span>
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full inline-block"></span>
            <span className="text-emerald-600 font-mono text-[10px] uppercase">100% Secure & Confidential</span>
          </p>
        </div>

        <button
          id="chat-clear-btn"
          onClick={clearChat}
          className="px-4 py-2 border border-slate-200 hover:border-red-100 text-slate-500 hover:text-red-500 hover:bg-red-50/50 bg-white font-sans font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span>Clear Dialogue</span>
        </button>
      </header>

      {/* Suggested Prompts rail (Horizontal Scroll) */}
      <section className="flex flex-wrap gap-2.5 py-4 shrink-0">
        {suggestedPrompts.map((prompt, idx) => (
          <button
            key={idx}
            id={`suggested-prompt-${idx}`}
            onClick={() => handleSuggestedPrompt(prompt)}
            disabled={sending}
            className="px-4 py-2 bg-white border border-slate-100 hover:border-blue-200 hover:bg-blue-50/20 text-slate-600 hover:text-blue-600 font-sans font-bold text-xs rounded-full cursor-pointer transition-all active:scale-95 disabled:opacity-50 flex items-center gap-1.5 shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>{prompt}</span>
          </button>
        ))}
      </section>

      {/* Messages Thread list */}
      <section className="flex-1 overflow-y-auto pr-2 pb-6 space-y-4 flex flex-col scrollbar-thin">
        {chatMessages.map((msg) => {
          const isUser = msg.sender === 'user';
          const isExpanded = expandedId === msg.id;
          const isSpeaking = speakingId === msg.id;

          return (
            <div 
              key={msg.id} 
              className={`flex flex-col max-w-2xl ${isUser ? 'self-end items-end' : 'self-start items-start'} gap-1`}
            >
              {/* Message bubble */}
              <div 
                className={`p-4 rounded-2xl text-sm font-medium leading-relaxed shadow-sm text-left ${
                  isUser 
                    ? 'bg-blue-600 text-white rounded-br-none' 
                    : 'bg-white border border-slate-100 text-slate-800 rounded-bl-none'
                }`}
              >
                {/* Text output */}
                <p className="whitespace-pre-line">{msg.text}</p>

                {/* Sub-cards inside AI responses (if any) */}
                {!isUser && msg.cards && msg.cards.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                    {msg.cards.map((card, cIdx) => (
                      <div key={cIdx} className="bg-slate-50 border border-slate-100 p-3 rounded-xl flex flex-col text-left gap-1">
                        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">{card.title}</span>
                        <span className="text-base font-extrabold text-slate-800">{card.value}</span>
                        {card.change && (
                          <span className={`text-[10px] font-bold ${card.type === 'danger' ? 'text-red-500' : card.type === 'success' ? 'text-emerald-500' : 'text-slate-500'}`}>
                            {card.change}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Message control actions footer (AI only) */}
              {!isUser && (
                <div className="flex items-center gap-3.5 px-1.5 text-[11px] font-bold text-slate-400">
                  <span className="font-mono text-[9px] uppercase tracking-wider">Secure Assistant</span>
                  
                  {/* Copy Button */}
                  <button 
                    onClick={() => handleCopy(msg.id, msg.text)}
                    className="hover:text-blue-600 transition-colors flex items-center gap-1 cursor-pointer"
                    title="Copy response"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                        <span className="text-emerald-500">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>

                  {/* Speak Button */}
                  <button 
                    onClick={() => handleSpeak(msg.id, msg.text)}
                    className={`hover:text-blue-600 transition-colors flex items-center gap-1 cursor-pointer ${isSpeaking ? 'text-blue-600' : ''}`}
                    title={isSpeaking ? "Mute speech" : "Speak response aloud"}
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="w-3.5 h-3.5 text-red-500" />
                        <span className="text-red-500">Mute</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Speak</span>
                      </>
                    )}
                  </button>

                  {/* Expand explanation accordion */}
                  {msg.explanation && (
                    <button 
                      onClick={() => toggleExpand(msg.id)}
                      className="hover:text-blue-600 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>Explain Metrics</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              )}

              {/* Expandable Explanation Area */}
              {isExpanded && msg.explanation && (
                <div className="bg-blue-50/50 border border-blue-100/30 text-blue-800 text-xs font-semibold p-3.5 rounded-xl mt-1.5 max-w-xl text-left leading-relaxed">
                  <p className="font-mono text-[9px] uppercase tracking-wider text-blue-500 mb-1">Analytical Reasoning Details</p>
                  {msg.explanation}
                </div>
              )}
            </div>
          );
        })}

        {/* Typing Loading Indicator */}
        {sending && (
          <div className="flex flex-col max-w-lg self-start items-start gap-1">
            <div className="p-4 rounded-2xl bg-white border border-slate-100 rounded-bl-none shadow-sm flex items-center gap-2">
              <span className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
              <span className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
              <span className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
            </div>
            <span className="text-[10px] font-mono font-bold text-slate-400 px-2 uppercase tracking-widest">Processing...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </section>

      {/* Input Form Footer (Fixed at bottom) */}
      <footer className="border-t border-slate-100 pt-4 bg-[#F8FAFC] shrink-0">
        <form onSubmit={handleSend} className="relative flex items-center gap-3">
          <input 
            type="text" 
            placeholder="Type your query... (e.g. Where did I overspend this month?)" 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={sending}
            className="w-full pl-5 pr-28 py-4 border border-slate-200 bg-white focus:bg-white rounded-2xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 shadow-sm"
          />

          <div className="absolute right-3.5 flex items-center gap-2">
            {/* Navigates directly to Voice Screen */}
            <button
              type="button"
              id="chat-mic-btn"
              onClick={() => navigate('/voice')}
              className="w-10 h-10 bg-amber-50 hover:bg-amber-100 border border-amber-100 text-amber-700 rounded-xl flex items-center justify-center transition-all cursor-pointer hover:scale-105 active:scale-95"
              title="Speak commands"
            >
              <Mic className="w-5 h-5" />
            </button>

            <button
              type="submit"
              id="chat-submit-btn"
              disabled={!inputText.trim() || sending}
              className="w-10 h-10 bg-blue-600 hover:bg-blue-700 text-white rounded-xl flex items-center justify-center transition-all disabled:opacity-45 cursor-pointer hover:scale-105 active:scale-95"
            >
              <Send className="w-4.5 h-4.5" />
            </button>
          </div>
        </form>
      </footer>
    </div>
  );
}

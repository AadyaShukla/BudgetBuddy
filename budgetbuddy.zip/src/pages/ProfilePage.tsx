import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFinance } from '../context/FinanceContext';
import { 
  User, 
  Mail, 
  Globe, 
  Lock, 
  LogOut, 
  Download, 
  ShieldAlert, 
  Check, 
  Cpu, 
  Sparkles,
  ToggleLeft,
  ToggleRight,
  Info
} from 'lucide-react';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { profile, updateProfile, transactions, budgets } = useFinance();

  // Profile Form States
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [currency, setCurrency] = useState(profile.currency);
  const [language, setLanguage] = useState(profile.language);
  const [savedMessage, setSavedMessage] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      email,
      currency,
      language
    });
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 2000);
  };

  const handleToggleOffline = () => {
    updateProfile({ offlineMode: !profile.offlineMode });
  };

  const handleToggleNotifications = () => {
    updateProfile({ notificationsEnabled: !profile.notificationsEnabled });
  };

  // Real Backup JSON Download
  const handleExportDataBackup = () => {
    const backupData = {
      profile,
      budgets,
      transactions,
      exportedAt: new Date().toISOString()
    };

    const str = JSON.stringify(backupData, null, 2);
    const blob = new Blob([str], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'budgetbuddy-profile-backup.json');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col gap-8">
      
      {/* Page Header */}
      <header>
        <h1 className="font-sans font-extrabold text-3xl text-slate-900 tracking-tight">Your Profile</h1>
        <p className="font-sans text-sm font-semibold text-slate-400 mt-1">Manage private user metrics, export backups, and configure edge scopes</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Form (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          
          {/* Main profile form */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5 text-left">
            <h2 className="font-sans font-bold text-lg text-slate-800">Local User Metrics</h2>
            
            {savedMessage && (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl p-3 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-bounce-slow">
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Profile metrics updated successfully across pages!</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="flex flex-col gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Full name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Your Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                    <input 
                      type="text" 
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-slate-200 focus:border-blue-500 bg-slate-50 rounded-xl text-sm font-semibold focus:outline-none"
                    />
                  </div>
                </div>

                {/* Email address */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-slate-200 focus:border-blue-500 bg-slate-50 rounded-xl text-sm font-semibold focus:outline-none"
                    />
                  </div>
                </div>

                {/* Preferred currency */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Default Currency Badge</label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="p-3 border border-slate-200 bg-slate-50 text-sm font-semibold rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    <option value="$">USD ($)</option>
                    <option value="₹">INR (₹)</option>
                    <option value="€">EUR (€)</option>
                    <option value="£">GBP (£)</option>
                  </select>
                </div>

                {/* Preferred language */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Preferred Interface Language</label>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="p-3 border border-slate-200 bg-slate-50 text-sm font-semibold rounded-xl focus:outline-none focus:border-blue-500"
                  >
                    <option value="English">English</option>
                    <option value="Hindi">Hindi (हिंदी)</option>
                  </select>
                </div>

              </div>

              <button
                type="submit"
                id="profile-save-btn"
                className="py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-sans font-bold text-sm tracking-wide rounded-xl shadow-md transition-all active:scale-98 text-center cursor-pointer mt-2 w-fit px-8"
              >
                Save Changes
              </button>
            </form>
          </div>

          {/* Backup & Import data */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 text-left">
            <h2 className="font-sans font-bold text-lg text-slate-800">Export sovereign assets</h2>
            <p className="text-xs font-semibold text-slate-400">
              Download your complete transaction ledger and budget slider bounds in JSON format. All files are compiled client-side in your own browser sandbox.
            </p>
            <button
              id="profile-export-backup-btn"
              onClick={handleExportDataBackup}
              className="py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-sans font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer w-fit px-6 shadow-md"
            >
              <Download className="w-4.5 h-4.5" />
              <span>Export Sovereign Backup (.json)</span>
            </button>
          </div>

        </div>

        {/* Right Column (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-8">
          
          {/* Edge Controls */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 text-left">
            <h2 className="font-sans font-bold text-base text-slate-800">Privacy & Cloud Controls</h2>
            
            <div className="flex flex-col gap-4">
              
              {/* Offline mode toggle */}
              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-100/50">
                <div>
                  <p className="text-xs font-bold text-slate-800">Local Privacy Mode</p>
                  <p className="text-[10px] text-slate-400">Keeps all data stored on-device</p>
                </div>
                <button id="toggle-offline-mode-btn" onClick={handleToggleOffline} className="cursor-pointer">
                  {profile.offlineMode ? (
                    <ToggleRight className="w-8 h-8 text-blue-600" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-slate-300" />
                  )}
                </button>
              </div>

              {/* Notification toggle */}
              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-100/50">
                <div>
                  <p className="text-xs font-bold text-slate-800">App Alerts</p>
                  <p className="text-[10px] text-slate-400">Enables dynamic ledger ticks</p>
                </div>
                <button id="toggle-notifications-btn" onClick={handleToggleNotifications} className="cursor-pointer">
                  {profile.notificationsEnabled ? (
                    <ToggleRight className="w-8 h-8 text-blue-600" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-slate-300" />
                  )}
                </button>
              </div>

            </div>
          </div>

          {/* About info block */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 text-left">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-blue-600" />
              <h2 className="font-sans font-bold text-base text-slate-800">About BudgetBuddy</h2>
            </div>
            <p className="text-xs font-semibold text-slate-500 leading-relaxed">
              BudgetBuddy is a premium, client-side personal finance companion. By running speech decoding and budget analysis algorithms securely on your device, BudgetBuddy ensures your sensitive financial logs remain completely confidential and secure.
            </p>
            <p className="text-[11px] font-mono font-semibold text-slate-400 uppercase tracking-widest border-t border-slate-50 pt-3">
              Version: 1.0.0 (Secure Release)
            </p>
          </div>

          {/* Logout Action */}
          <button
            id="profile-logout-btn"
            onClick={() => navigate('/')}
            className="w-full py-3 border border-red-100 bg-red-50/50 text-red-600 font-sans font-bold text-sm rounded-xl flex items-center justify-center gap-2 hover:bg-red-50 transition-all active:scale-98"
          >
            <LogOut className="w-4.5 h-4.5" />
            <span>Sign Out Session</span>
          </button>

        </div>

      </div>

    </div>
  );
}

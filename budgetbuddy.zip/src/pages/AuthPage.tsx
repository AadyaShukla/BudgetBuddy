import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Cpu, Sparkles, Mail, Lock, User, ArrowRight, ArrowLeft } from 'lucide-react';

export default function AuthPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'login' | 'signup' | 'forgot'>(
    (searchParams.get('tab') as 'login' | 'signup' | 'forgot') || 'login'
  );

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam === 'login' || tabParam === 'signup' || tabParam === 'forgot') {
      setActiveTab(tabParam);
    }
  }, [searchParams]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess('');

    // Simulate authentic firebase validation delay
    setTimeout(() => {
      setLoading(false);
      if (activeTab === 'forgot') {
        setSuccess('Password reset link sent to your email address!');
      } else {
        // Authenticate successfully and head to dashboard
        navigate('/dashboard');
      }
    }, 800);
  };

  const handleGoogleSignIn = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate('/dashboard');
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Absolute ambient lights */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400 rounded-full blur-3xl opacity-10 animate-pulse-slow"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-teal-400 rounded-full blur-3xl opacity-10 animate-pulse-slow"></div>

      <div className="w-full max-w-md relative z-10">
        {/* Brand Header */}
        <div 
          onClick={() => navigate('/')} 
          className="flex flex-col items-center gap-2.5 mb-8 cursor-pointer group"
          id="auth-brand-header"
        >
          <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-200 group-hover:scale-105 transition-all">
            <Cpu className="w-6.5 h-6.5" />
          </div>
          <div className="text-center">
            <span className="font-sans font-bold text-2xl tracking-tight text-slate-800">
              Budget<span className="text-blue-600">Buddy</span>
            </span>
            <div className="flex items-center gap-1 justify-center mt-0.5">
              <span className="text-[9px] font-mono font-bold tracking-widest text-teal-600 uppercase">Snapdragon AI Elite</span>
              <Sparkles className="w-2.5 h-2.5 text-teal-500 fill-teal-500 animate-pulse" />
            </div>
          </div>
        </div>

        {/* Card Body */}
        <div className="bg-white border border-slate-100 p-8 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-6 text-left">
          {activeTab === 'login' && (
            <div className="flex flex-col gap-1">
              <h2 className="font-sans font-bold text-2xl text-slate-800">Welcome back</h2>
              <p className="text-xs font-semibold text-slate-400">Offline NPU secure local authentication tunnel</p>
            </div>
          )}
          {activeTab === 'signup' && (
            <div className="flex flex-col gap-1">
              <h2 className="font-sans font-bold text-2xl text-slate-800">Create Private Account</h2>
              <p className="text-xs font-semibold text-slate-400">Generate on-device secure cryptographic profile</p>
            </div>
          )}
          {activeTab === 'forgot' && (
            <div className="flex flex-col gap-1">
              <h2 className="font-sans font-bold text-2xl text-slate-800">Forgot Password?</h2>
              <p className="text-xs font-semibold text-slate-400">Enter your email to request localized reset token</p>
            </div>
          )}

          {/* Success Alerts */}
          {success && (
            <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl p-3 text-xs font-bold text-center">
              {success}
            </div>
          )}

          {/* Form wrapper */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {activeTab === 'signup' && (
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Your Full Name</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Saraswati Choudhary" 
                    required 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10.5 pr-4 py-3.5 border border-slate-200 focus:border-blue-500 bg-slate-50/50 focus:bg-white rounded-xl text-sm font-semibold focus:outline-none transition-all text-slate-800" 
                  />
                </div>
              </div>
            )}

            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                <input 
                  type="email" 
                  placeholder="saraswatichoudhary1997@gmail.com" 
                  required 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10.5 pr-4 py-3.5 border border-slate-200 focus:border-blue-500 bg-slate-50/50 focus:bg-white rounded-xl text-sm font-semibold focus:outline-none transition-all text-slate-800" 
                />
              </div>
            </div>

            {activeTab !== 'forgot' && (
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Password</label>
                  {activeTab === 'login' && (
                    <button 
                      type="button"
                      id="auth-forgot-btn"
                      onClick={() => setActiveTab('forgot')}
                      className="text-[10px] font-bold text-blue-600 hover:underline"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
                  <input 
                    type="password" 
                    placeholder="••••••••" 
                    required 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10.5 pr-4 py-3.5 border border-slate-200 focus:border-blue-500 bg-slate-50/50 focus:bg-white rounded-xl text-sm font-semibold focus:outline-none transition-all text-slate-800" 
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              id="auth-submit-btn"
              disabled={loading}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-sans font-bold text-sm tracking-wide rounded-xl shadow-md shadow-blue-100 flex items-center justify-center gap-2 transition-all active:scale-98 disabled:opacity-50 cursor-pointer mt-2"
            >
              <span>{loading ? 'Processing Securely...' : activeTab === 'login' ? 'Sign In Locally' : activeTab === 'signup' ? 'Create Local Cryptography' : 'Send Reset Link'}</span>
              {!loading && <ArrowRight className="w-4 h-4" />}
            </button>
          </form>

          {/* Social Separator */}
          <div className="flex items-center justify-center gap-3">
            <div className="flex-1 h-[1px] bg-slate-100"></div>
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">or continue with</span>
            <div className="flex-1 h-[1px] bg-slate-100"></div>
          </div>

          {/* Google button (Firebase Authentication ready) */}
          <button
            type="button"
            id="auth-google-btn"
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full py-3 border border-slate-200 hover:border-slate-300 hover:bg-slate-50 bg-white text-slate-700 font-sans font-semibold text-sm rounded-xl flex items-center justify-center gap-2.5 transition-all active:scale-98"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.4l3.7 2.9C6.5 7.1 9 5 12 5z" />
              <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.4h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.7z" />
              <path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.4C1 9.2.5 11.2.5 13.3c0 2.1.5 4.1 1.4 5.9l3.7-2.9z" />
              <path fill="#34A853" d="M12 23c3.2 0 6-1.1 8-2.9l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.1-6.4-5.3L1.9 16c1.8 3.8 5.6 7 10.1 7z" />
            </svg>
            <span>Google Single Sign In</span>
          </button>

          {/* Tab togglers */}
          <div className="border-t border-slate-100 pt-4 flex justify-between items-center text-xs font-semibold">
            {activeTab === 'login' ? (
              <>
                <span className="text-slate-400">Need an offline account?</span>
                <button 
                  id="auth-toggle-signup-btn"
                  onClick={() => setActiveTab('signup')}
                  className="text-blue-600 hover:underline"
                >
                  Create one now
                </button>
              </>
            ) : activeTab === 'signup' ? (
              <>
                <span className="text-slate-400">Already have an account?</span>
                <button 
                  id="auth-toggle-login-btn"
                  onClick={() => setActiveTab('login')}
                  className="text-blue-600 hover:underline"
                >
                  Sign in instead
                </button>
              </>
            ) : (
              <button 
                id="auth-toggle-back-login-btn"
                onClick={() => setActiveTab('login')}
                className="text-slate-500 hover:text-blue-600 flex items-center gap-1.5 hover:underline"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Login</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

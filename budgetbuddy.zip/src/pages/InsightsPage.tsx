import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { 
  TrendingUp, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign, 
  Calendar, 
  CreditCard, 
  UserCheck,
  ChevronDown,
  ChevronUp,
  Activity,
  ArrowRight
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';

export default function InsightsPage() {
  const { transactions, budgets, formatCurrency } = useFinance();
  const [activeAccordion, setActiveAccordion] = useState<number | null>(null);

  // Derive dynamic stats
  const expenses = transactions.filter(t => t.type === 'expense');
  const totalSpent = expenses.reduce((sum, t) => sum + t.amount, 0);
  
  // Average daily spend: July 9 is the current date -> 9 days elapsed
  const avgDailySpend = parseFloat((totalSpent / 9).toFixed(2));

  // Find largest expense
  const sortedExpenses = [...expenses].sort((a, b) => b.amount - a.amount);
  const largestExpense = sortedExpenses[0] || { merchant: 'None', amount: 0 };

  // Find top merchant (group by merchant, select highest total)
  const merchantTotals: Record<string, number> = {};
  expenses.forEach(t => {
    merchantTotals[t.merchant] = (merchantTotals[t.merchant] || 0) + t.amount;
  });
  const topMerchantEntry = Object.entries(merchantTotals).sort((a, b) => b[1] - a[1])[0];
  const topMerchant = topMerchantEntry ? topMerchantEntry[0] : 'None';
  const topMerchantAmount = topMerchantEntry ? topMerchantEntry[1] : 0;

  // Recharts BarChart data comparing Limit vs Spent
  const comparisonData = budgets.map(b => ({
    name: b.name.slice(0, 10), // truncate for clean labeling
    Limit: b.limit,
    Spent: b.spent
  }));

  const recommendations = [
    {
      title: "Consolidate Entertainment Subscriptions",
      impact: `Save ${formatCurrency(24)}/mo`,
      description: "You currently maintain dual music and video streaming services. Consolidating into a family pack or pausing unused cycles can free up disposable investment margins without lifestyle impact.",
      scoreBoost: "+2 pts Health Score"
    },
    {
      title: "Optimize Commute Travel Windows",
      impact: `Save ${formatCurrency(32)}/mo`,
      description: "Uber trips during peak surge times account for 45% of transport overheads. Rescheduling travel blocks or checking alternative lanes can easily trim down this non-essential spending.",
      scoreBoost: "+3 pts Health Score"
    },
    {
      title: "Transition High Food Outlays to Prep Plan",
      impact: `Save ${formatCurrency(85)}/mo`,
      description: "Blue Bottle coffee runs and small snacking baskets sum up to a noticeable amount. Planning grocery orders ahead of time limits impulse checkout behaviors.",
      scoreBoost: "+5 pts Health Score"
    }
  ];

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col gap-8">
      
      {/* Top Banner Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-sans font-extrabold text-3xl text-slate-900 tracking-tight">Financial Insights</h1>
          <p className="font-sans text-sm font-semibold text-slate-400 mt-1">Deep analysis of spending velocity and behavioral loops</p>
        </div>

        <div className="flex items-center gap-2.5 bg-blue-50 border border-blue-100 text-blue-700 font-sans font-bold text-xs uppercase tracking-widest px-3.5 py-1.5 rounded-full">
          <Activity className="w-4 h-4 text-blue-600 animate-pulse" />
          <span>Real-time Insights Active</span>
        </div>
      </header>

      {/* Overview Analytics Grids */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Largest Expense Card */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-3">Largest Expense</p>
          <p className="text-xl font-extrabold text-slate-800 leading-none">{largestExpense.merchant}</p>
          <p className="text-2xl font-extrabold text-red-600 mt-2">{formatCurrency(largestExpense.amount)}</p>
          <p className="text-xs font-semibold text-slate-400 mt-2">Single outlay on {largestExpense.category}</p>
        </div>

        {/* Top Merchant Spends Card */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-3">Top Merchant</p>
          <p className="text-xl font-extrabold text-slate-800 leading-none">{topMerchant}</p>
          <p className="text-2xl font-extrabold text-blue-600 mt-2">{formatCurrency(topMerchantAmount)}</p>
          <p className="text-xs font-semibold text-slate-400 mt-2">Accumulated spend across July transactions</p>
        </div>

        {/* Average Daily Velocity Card */}
        <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] hover:shadow-md transition-all duration-300">
          <p className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-3">Daily Spending Velocity</p>
          <p className="text-xl font-extrabold text-slate-800 leading-none">Average Daily Spend</p>
          <p className="text-2xl font-extrabold text-slate-800 mt-2">{formatCurrency(avgDailySpend)} / day</p>
          <p className="text-xs font-semibold text-slate-400 mt-2">Aggregated over 9 elapsed days of July</p>
        </div>

      </section>

      {/* Comparison Chart & Recommendation layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left BarChart Comparison (7 columns) */}
        <div className="lg:col-span-7 bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5">
          <div>
            <h2 className="font-sans font-bold text-lg text-slate-800">Limits vs Spent comparison</h2>
            <p className="text-xs font-semibold text-slate-400 mt-0.5">Dual bar alignment of budget bounds vs outlays</p>
          </div>

          <div className="w-full h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="name" stroke="#94A3B8" fontSize={9} tickLine={false} axisLine={false} />
                <YAxis stroke="#94A3B8" fontSize={9} tickLine={false} axisLine={false} tickFormatter={(value) => formatCurrency(Number(value))} />
                <Tooltip formatter={(value) => [formatCurrency(Number(value)), 'Amount']} />
                <Legend iconSize={10} wrapperStyle={{ fontSize: 11, fontWeight: '600' }} />
                <Bar dataKey="Limit" fill="#2563EB" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Spent" fill="#0F766E" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right AI recommendations (5 columns) */}
        <div className="lg:col-span-5 bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-600 animate-pulse" />
            <h2 className="font-sans font-bold text-base text-slate-800">Smart AI Recommendations</h2>
          </div>
          <p className="text-xs font-semibold text-slate-400">
            Smart observations synthesized from your spending velocity:
          </p>

          <div className="flex flex-col gap-3">
            {recommendations.map((rec, idx) => {
              const isAccordionActive = activeAccordion === idx;
              return (
                <div key={idx} className="border border-slate-50 bg-slate-50/20 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setActiveAccordion(isAccordionActive ? null : idx)}
                    className="w-full p-4 text-left flex justify-between items-center hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-800">{rec.title}</p>
                      <span className="text-[10px] font-mono font-bold text-emerald-600 mt-0.5 inline-block">{rec.impact}</span>
                    </div>
                    {isAccordionActive ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </button>

                  {isAccordionActive && (
                    <div className="p-4 bg-white border-t border-slate-100 text-xs font-semibold text-slate-500 leading-relaxed text-left flex flex-col gap-2">
                      <p>{rec.description}</p>
                      <div className="flex justify-between items-center pt-2 mt-1 border-t border-slate-100">
                        <span className="text-blue-600 font-bold">{rec.scoreBoost}</span>
                        <span className="text-[10px] uppercase font-bold text-teal-600">Verified Advice</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
}

import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { 
  Settings, 
  Cpu, 
  Volume2, 
  Bell, 
  Database, 
  ShieldCheck, 
  ToggleLeft, 
  ToggleRight,
  Sparkles,
  Info
} from 'lucide-react';

export default function SettingsPage() {
  const { npuSettings, updateNpuSettings } = useFinance();

  const toggleSms = () => {
    updateNpuSettings({ smsPermission: !npuSettings.smsPermission });
  };

  const toggleMic = () => {
    updateNpuSettings({ micPermission: !npuSettings.micPermission });
  };

  const handleWhisperChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateNpuSettings({ whisperModel: e.target.value });
  };

  const handlePhiChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateNpuSettings({ phiModel: e.target.value });
  };

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left flex flex-col gap-8">
      
      {/* Page Header */}
      <header>
        <h1 className="font-sans font-extrabold text-3xl text-slate-900 tracking-tight">System Settings</h1>
        <p className="font-sans text-sm font-semibold text-slate-400 mt-1">Configure budget automation, security preferences, and active currency scopes</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Models & Permissions (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          
          {/* AI Model Config Card */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-5 text-left">
            <h2 className="font-sans font-bold text-lg text-slate-800 flex items-center gap-2">
              <Cpu className="w-5.5 h-5.5 text-blue-600" />
              <span>Intelligence Settings</span>
            </h2>
            <p className="text-xs font-semibold text-slate-400">
              Manage automated analytical engines and predictive models to categorize transactions and parse voice commands:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              
              {/* Analytics Depth selection */}
              <div className="flex flex-col gap-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Analytics Processing Depth</label>
                <select
                  value={npuSettings.phiModel}
                  onChange={handlePhiChange}
                  className="p-3 border border-slate-200 bg-slate-50 text-sm font-semibold rounded-xl focus:outline-none focus:border-blue-500"
                >
                  <option value="Phi-3-mini-4k-instruct-Q4_K_M">Balanced Analysis (Standard)</option>
                  <option value="Gemma-2b-it-Q4_K_M">Comprehensive Analysis (Deep)</option>
                  <option value="Llama-3-8b-instruct-Q2_K">Quick Overview (Fast)</option>
                </select>
                <p className="text-[10px] font-medium text-slate-400">Optimizes automated classifications and budget suggestions.</p>
              </div>

              {/* Voice Input Precision selection */}
              <div className="flex flex-col gap-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Voice Recognition Precision</label>
                <select
                  value={npuSettings.whisperModel}
                  onChange={handleWhisperChange}
                  className="p-3 border border-slate-200 bg-slate-50 text-sm font-semibold rounded-xl focus:outline-none focus:border-blue-500"
                >
                  <option value="Whisper-base.en (Quantized)">Standard Accuracy (English)</option>
                  <option value="Whisper-tiny.multilingual">Multilingual Precision (Hindi/English)</option>
                  <option value="Whisper-medium.en">High Fidelity Precision (Adaptive)</option>
                </select>
                <p className="text-[10px] font-medium text-slate-400">Controls voice synthesis, phrase processing, and response lag.</p>
              </div>

            </div>
          </div>

          {/* Local Security Permissions Card */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 text-left">
            <h2 className="font-sans font-bold text-lg text-slate-800 flex items-center gap-2">
              <ShieldCheck className="w-5.5 h-5.5 text-blue-600" />
              <span>Privacy & Access Permissions</span>
            </h2>
            <p className="text-xs font-semibold text-slate-400 mb-2">
              Grant BudgetBuddy permission to tap into secure streams. All details remain securely stored inside your client sandbox:
            </p>

            <div className="flex flex-col gap-4">
              
              {/* Mic Permission toggle */}
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100/50">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center font-bold text-sm shrink-0">🎙️</div>
                  <div>
                    <p className="text-sm font-bold text-slate-800">Microphone Input</p>
                    <p className="text-[10px] font-semibold text-slate-400">Enables direct hands-free financial command routing</p>
                  </div>
                </div>
                <button id="toggle-mic-permission-btn" onClick={toggleMic} className="cursor-pointer">
                  {npuSettings.micPermission ? (
                    <ToggleRight className="w-9 h-9 text-blue-600" />
                  ) : (
                    <ToggleLeft className="w-9 h-9 text-slate-300" />
                  )}
                </button>
              </div>

              {/* SMS Permission toggle */}
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100/50">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold text-sm shrink-0">💬</div>
                  <div>
                    <p className="text-sm font-bold text-slate-800">SMS Transaction Access</p>
                    <p className="text-[10px] font-semibold text-slate-400">Enables automated categorizer to parse transaction alert messages</p>
                  </div>
                </div>
                <button id="toggle-sms-permission-btn" onClick={toggleSms} className="cursor-pointer">
                  {npuSettings.smsPermission ? (
                    <ToggleRight className="w-9 h-9 text-blue-600" />
                  ) : (
                    <ToggleLeft className="w-9 h-9 text-slate-300" />
                  )}
                </button>
              </div>

            </div>
          </div>

        </div>

        {/* Right Column: Status & Storage (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-8">
          
          {/* Diagnostics metrics */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 text-left">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-blue-600" />
              <h2 className="font-sans font-bold text-base text-slate-800">System Diagnostics</h2>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex justify-between items-center text-xs font-bold border-b border-slate-50 pb-2">
                <span className="text-slate-400">Security Layer</span>
                <span className="text-slate-700 font-mono text-right">Sovereign Sandbox Cryptography</span>
              </div>
              <div className="flex justify-between items-center text-xs font-bold border-b border-slate-50 pb-2">
                <span className="text-slate-400">Core Engine Status</span>
                <span className="inline-flex items-center gap-1 text-emerald-600 font-mono">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
                  <span>Active & Secure</span>
                </span>
              </div>
              <div className="flex justify-between items-center text-xs font-bold border-b border-slate-50 pb-2">
                <span className="text-slate-400">Data Encryption</span>
                <span className="text-slate-700 font-mono">AES-256 Client-Side</span>
              </div>
              <div className="flex justify-between items-center text-xs font-bold pb-1">
                <span className="text-slate-400">Connection Layer</span>
                <span className="text-emerald-600 font-bold">Zero Cloud Tracking</span>
              </div>
            </div>
          </div>

          {/* Storage tracker */}
          <div className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 text-left">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-600" />
              <h2 className="font-sans font-bold text-base text-slate-800">Local Sandbox Storage</h2>
            </div>
            
            <div className="flex flex-col gap-2">
              <div className="flex justify-between text-xs font-bold text-slate-500">
                <span>Storage Occupied</span>
                <span>4.2 MB</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full rounded-full" style={{ width: '6.5%' }}></div>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100/50 flex flex-col gap-1 text-slate-500 text-[11px] font-semibold leading-relaxed">
              <p>• Ledger Cache: 2.2 MB</p>
              <p>• Analytical Database Index: 1.4 MB</p>
              <p>• Local Preferences: 0.6 MB</p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}

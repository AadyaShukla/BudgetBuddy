import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { 
  Search, 
  Filter, 
  Download, 
  Plus, 
  Trash2, 
  ChevronLeft, 
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  X
} from 'lucide-react';

export default function TransactionsPage() {
  const { 
    transactions, 
    budgets, 
    addTransaction, 
    deleteTransaction,
    profile,
    formatCurrency
  } = useFinance();

  // Modal State
  const [isAddTxOpen, setIsAddTxOpen] = useState(false);
  const [selectedTx, setSelectedTx] = useState<any>(null);

  // Form states
  const [txMerchant, setTxMerchant] = useState('');
  const [txAmount, setTxAmount] = useState('');
  const [txCategory, setTxCategory] = useState('Food & Drinks');
  const [txType, setTxType] = useState<'income' | 'expense'>('expense');
  const [txMethod, setTxMethod] = useState('Credit Card');
  const [txDate, setTxDate] = useState('2026-07-09');

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterMethod, setFilterMethod] = useState('All');
  const [filterType, setFilterType] = useState('All');
  const [filterDate, setFilterDate] = useState('All');
  const [filterMerchant, setFilterMerchant] = useState('All');

  // Unique Merchants for filtering
  const uniqueMerchants = Array.from(new Set(transactions.map((tx) => tx.merchant))).sort();

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter Logic
  const filteredTransactions = transactions.filter((tx) => {
    const matchesSearch = tx.merchant.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tx.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          tx.paymentMethod.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'All' || tx.category === filterCategory;
    const matchesMethod = filterMethod === 'All' || tx.paymentMethod === filterMethod;
    const matchesType = filterType === 'All' || tx.type === filterType;
    const matchesMerchant = filterMerchant === 'All' || tx.merchant === filterMerchant;

    // Date range preset logic
    let matchesDate = true;
    if (filterDate !== 'All') {
      const txDateObj = new Date(tx.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      if (filterDate === 'Today') {
        const txDateFormatted = tx.date; // YYYY-MM-DD
        const todayFormatted = today.toISOString().split('T')[0];
        matchesDate = txDateFormatted === todayFormatted;
      } else if (filterDate === 'Week') {
        const diffTime = Math.abs(today.getTime() - txDateObj.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        matchesDate = diffDays <= 7;
      } else if (filterDate === 'Month') {
        const diffTime = Math.abs(today.getTime() - txDateObj.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        matchesDate = diffDays <= 30;
      }
    }

    return matchesSearch && matchesCategory && matchesMethod && matchesType && matchesMerchant && matchesDate;
  });

  // Pagination Calculations
  const totalItems = filteredTransactions.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleAddTxSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!txMerchant || !txAmount) return;

    addTransaction({
      date: txDate,
      category: txCategory,
      merchant: txMerchant,
      amount: parseFloat(txAmount),
      type: txType,
      paymentMethod: txMethod,
      status: 'completed'
    });

    // Reset Form & Close
    setTxMerchant('');
    setTxAmount('');
    setIsAddTxOpen(false);
    setCurrentPage(1); // Go back to page 1 to see the new entry
  };

  // Real Export CSV Utility
  const handleExportCSV = () => {
    if (transactions.length === 0) return;

    // Build header row
    const headers = ['ID', 'Date', 'Type', 'Category', 'Merchant', 'Amount', 'PaymentMethod', 'Status'];
    const rows = transactions.map((t) => [
      t.id,
      t.date,
      t.type,
      t.category,
      t.merchant,
      t.amount,
      t.paymentMethod,
      t.status
    ]);

    const csvContent = [headers, ...rows]
      .map((e) => e.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'budgetbuddy-transactions.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 bg-[#F8FAFC] min-h-screen p-6 sm:p-8 ml-0 md:ml-64 text-slate-800 text-left relative">
      
      {/* Top Section */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-sans font-extrabold text-3xl text-slate-900 tracking-tight">Ledger Journal</h1>
          <p className="font-sans text-sm font-semibold text-slate-400 mt-1">Detailed transaction history logs processed offline</p>
        </div>

        <button
          id="tx-export-csv-btn"
          onClick={handleExportCSV}
          className="px-5 py-3 border border-slate-200 hover:bg-slate-50 text-slate-700 bg-white font-sans font-bold text-sm tracking-wide rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer active:scale-95"
        >
          <Download className="w-4 h-4 text-slate-500" />
          <span>Export Ledger CSV</span>
        </button>
      </header>

      {/* Filter and Search Panel */}
      <section className="bg-white border border-slate-100 p-6 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] flex flex-col gap-4 mb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-12 gap-4">
          
          {/* Search bar (4 cols) */}
          <div className="md:col-span-4 relative">
            <Search className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search merchant, tags, ledger entries..." 
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              className="w-full pl-10 pr-4 py-3 border border-slate-200 bg-slate-50/50 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800"
            />
          </div>

          {/* Category Filter (2 cols) */}
          <div className="md:col-span-2">
            <select
              value={filterCategory}
              onChange={(e) => { setFilterCategory(e.target.value); setCurrentPage(1); }}
              className="w-full p-3 border border-slate-200 bg-slate-50/50 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-700 bg-white"
            >
              <option value="All">All Categories</option>
              {budgets.map(b => (
                <option key={b.id} value={b.name}>{b.name}</option>
              ))}
              <option value="Investment">Investment</option>
              <option value="Salary">Salary</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Payment Method Filter (2 cols) */}
          <div className="md:col-span-2">
            <select
              value={filterMethod}
              onChange={(e) => { setFilterMethod(e.target.value); setCurrentPage(1); }}
              className="w-full p-3 border border-slate-200 bg-slate-50/50 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-700 bg-white"
            >
              <option value="All">All Methods</option>
              <option value="Credit Card">Credit Card</option>
              <option value="Debit Card">Debit Card</option>
              <option value="Apple Pay">Apple Pay</option>
              <option value="Google Wallet">Google Wallet</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cash">Cash</option>
            </select>
          </div>

          {/* Date Filter (2 cols) */}
          <div className="md:col-span-2">
            <select
              value={filterDate}
              onChange={(e) => { setFilterDate(e.target.value); setCurrentPage(1); }}
              className="w-full p-3 border border-slate-200 bg-slate-50/50 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-700 bg-white"
            >
              <option value="All">All Time</option>
              <option value="Today">Today Only</option>
              <option value="Week">Last 7 Days</option>
              <option value="Month">Last 30 Days</option>
            </select>
          </div>

          {/* Merchant Filter (2 cols) */}
          <div className="md:col-span-2">
            <select
              value={filterMerchant}
              onChange={(e) => { setFilterMerchant(e.target.value); setCurrentPage(1); }}
              className="w-full p-3 border border-slate-200 bg-slate-50/50 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-700 bg-white"
            >
              <option value="All">All Merchants</option>
              {uniqueMerchants.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

        </div>
      </section>

      {/* Main Journal Data Table / Mobile Cards */}
      <section className="bg-white border border-slate-100 rounded-[24px] shadow-[0_4px_20px_-2px_rgba(15,23,42,0.02)] overflow-hidden mb-8">
        
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/70 border-b border-slate-100 text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">
                <th className="py-4.5 px-6">Date</th>
                <th className="py-4.5 px-6">Merchant / Source</th>
                <th className="py-4.5 px-6">Category</th>
                <th className="py-4.5 px-6">Method</th>
                <th className="py-4.5 px-6">Status</th>
                <th className="py-4.5 px-6 text-right">Amount</th>
                <th className="py-4.5 px-6 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm font-semibold text-slate-700">
              {paginatedTransactions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    No transactions matching the filter criteria found.
                  </td>
                </tr>
              ) : (
                paginatedTransactions.map((tx) => (
                  <tr 
                    key={tx.id} 
                    onClick={() => setSelectedTx(tx)}
                    className="hover:bg-slate-50/50 transition-colors group cursor-pointer"
                  >
                    <td className="py-4 px-6 text-xs text-slate-500 font-mono">{tx.date}</td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 border border-slate-100/50 rounded-xl bg-white shadow-sm flex items-center justify-center font-bold text-sm shrink-0">
                          {tx.category === 'Food & Drinks' ? '🍱' : 
                           tx.category === 'Shopping' ? '🛍️' : 
                           tx.category === 'Salary' ? '💵' : 
                           tx.category === 'Transport' ? '🚗' : 
                           tx.category === 'Entertainment' ? '🎬' : '📝'}
                        </div>
                        <span className="font-bold text-slate-800">{tx.merchant}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-slate-50 border border-slate-100">
                        {tx.category}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-xs text-slate-500">{tx.paymentMethod}</td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${tx.status === 'completed' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                        {tx.status}
                      </span>
                    </td>
                    <td className={`py-4 px-6 text-right font-bold text-base ${tx.type === 'income' ? 'text-emerald-600' : 'text-slate-800'}`}>
                      {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </td>
                    <td className="py-4 px-6 text-center">
                      <button 
                        id={`tx-delete-${tx.id}`}
                        onClick={(e) => { e.stopPropagation(); deleteTransaction(tx.id); }}
                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all active:scale-95 cursor-pointer opacity-0 group-hover:opacity-100"
                        title="Delete journal entry"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile View Card List */}
        <div className="md:hidden flex flex-col divide-y divide-slate-100">
          {paginatedTransactions.length === 0 ? (
            <p className="py-12 text-center text-slate-400 text-sm">
              No transactions matching the filter criteria found.
            </p>
          ) : (
            paginatedTransactions.map((tx) => (
              <div 
                key={tx.id} 
                onClick={() => setSelectedTx(tx)}
                className="p-4 flex flex-col gap-3 cursor-pointer hover:bg-slate-50/50 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 border border-slate-100 bg-white rounded-xl flex items-center justify-center font-bold text-base">
                      {tx.category === 'Food & Drinks' ? '🍱' : 
                       tx.category === 'Shopping' ? '🛍️' : 
                       tx.category === 'Salary' ? '💵' : 
                       tx.category === 'Transport' ? '🚗' : 
                       tx.category === 'Entertainment' ? '🎬' : '📝'}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800">{tx.merchant}</p>
                      <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mt-0.5">{tx.category} • {tx.paymentMethod}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className={`text-sm font-bold ${tx.type === 'income' ? 'text-emerald-600' : 'text-slate-800'}`}>
                      {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </p>
                    <span className="text-[10px] font-mono text-slate-400 block mt-0.5">{tx.date}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-slate-50 pt-2.5">
                  <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${tx.status === 'completed' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                    {tx.status}
                  </span>

                  <button 
                    id={`tx-delete-mobile-${tx.id}`}
                    onClick={(e) => { e.stopPropagation(); deleteTransaction(tx.id); }}
                    className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg flex items-center gap-1 text-[10px] font-bold"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

      </section>

      {/* Pagination Controls */}
      <footer className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-400">
          Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} logs
        </span>

        <div className="flex items-center gap-2">
          <button
            id="tx-page-prev-btn"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            className="w-10 h-10 border border-slate-200 bg-white rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-50 disabled:opacity-40 transition-all cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="text-xs font-bold text-slate-700 font-mono px-2">
            Page {currentPage} of {totalPages}
          </span>
          <button
            id="tx-page-next-btn"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            className="w-10 h-10 border border-slate-200 bg-white rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-50 disabled:opacity-40 transition-all cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </footer>

      {/* Floating Add Button for Mobile/Desktop */}
      <button
        id="floating-add-tx-btn"
        onClick={() => setIsAddTxOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-xl shadow-blue-300 hover:scale-105 active:scale-95 transition-all z-30 cursor-pointer"
        title="Add transaction log"
      >
        <Plus className="w-6 h-6 stroke-[3]" />
      </button>

      {/* --- Working Modal: Add Transaction --- */}
      {isAddTxOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl w-full max-w-md text-left flex flex-col gap-5">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-sans font-bold text-lg text-slate-800">Add Transaction Record</h3>
              <button 
                id="modal-close-add-tx-btn-tx-page"
                onClick={() => setIsAddTxOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <form onSubmit={handleAddTxSubmit} className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  id="modal-tx-type-expense-btn-tx"
                  onClick={() => setTxType('expense')}
                  className={`py-2 text-xs font-bold rounded-lg transition-all ${txType === 'expense' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Expense
                </button>
                <button
                  type="button"
                  id="modal-tx-type-income-btn-tx"
                  onClick={() => setTxType('income')}
                  className={`py-2 text-xs font-bold rounded-lg transition-all ${txType === 'income' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  Income
                </button>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Merchant / Source Name</label>
                <input 
                  type="text" 
                  placeholder="e.g. Whole Foods, Amazon, payroll salary" 
                  required 
                  value={txMerchant}
                  onChange={(e) => setTxMerchant(e.target.value)}
                  className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Amount ({profile.currency})</label>
                  <input 
                    type="number" 
                    step="0.01"
                    placeholder="24.50" 
                    required 
                    value={txAmount}
                    onChange={(e) => setTxAmount(e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Payment Method</label>
                  <select 
                    value={txMethod}
                    onChange={(e) => setTxMethod(e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 bg-white"
                  >
                    <option value="Credit Card">Credit Card</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="Apple Pay">Apple Pay</option>
                    <option value="Google Wallet">Google Wallet</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cash">Cash</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Category</label>
                  <select 
                    value={txCategory}
                    onChange={(e) => setTxCategory(e.target.value)}
                    disabled={txType === 'income'}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 bg-white disabled:opacity-50"
                  >
                    {budgets.map(b => (
                      <option key={b.id} value={b.name}>{b.name}</option>
                    ))}
                    <option value="Investment">Investment</option>
                    <option value="Salary">Salary</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Date</label>
                  <input 
                    type="date" 
                    required 
                    value={txDate}
                    onChange={(e) => setTxDate(e.target.value)}
                    className="p-3 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-blue-500 text-slate-800 bg-white"
                  />
                </div>
              </div>

              <button 
                type="submit"
                id="modal-tx-submit-btn-tx"
                className="py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-sans font-bold text-sm tracking-wide rounded-xl shadow-md transition-all active:scale-98 text-center cursor-pointer mt-2"
              >
                Log Transaction Record
              </button>
            </form>
          </div>
        </div>
      )}

      {/* --- Working Modal: Transaction Details --- */}
      {selectedTx && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xl w-full max-w-md text-left flex flex-col gap-5">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-sans font-bold text-lg text-slate-800">Transaction Details</h3>
              <button 
                id="modal-close-tx-details-btn"
                onClick={() => setSelectedTx(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>

            <div className="flex flex-col items-center gap-3 py-4 border-b border-slate-50">
              <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl font-bold">
                {selectedTx.category === 'Food & Drinks' ? '🍱' : 
                 selectedTx.category === 'Shopping' ? '🛍️' : 
                 selectedTx.category === 'Salary' ? '💵' : 
                 selectedTx.category === 'Transport' ? '🚗' : 
                 selectedTx.category === 'Entertainment' ? '🎬' : '📝'}
              </div>
              <div className="text-center">
                <p className="text-xl font-sans font-extrabold text-slate-800">{selectedTx.merchant}</p>
                <p className={`text-2xl font-mono font-extrabold mt-1 ${selectedTx.type === 'income' ? 'text-emerald-600' : 'text-slate-900'}`}>
                  {selectedTx.type === 'income' ? '+' : '-'}{formatCurrency(selectedTx.amount)}
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-3.5 text-sm font-semibold text-slate-700">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Date</span>
                <span className="font-mono text-slate-800">{selectedTx.date}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Category Tag</span>
                <span className="px-2.5 py-1 bg-slate-50 border border-slate-100 rounded-lg text-xs font-bold text-slate-800">
                  {selectedTx.category}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Payment Method</span>
                <span className="text-slate-800">{selectedTx.paymentMethod}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${selectedTx.status === 'completed' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                  {selectedTx.status}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Transaction ID</span>
                <span className="font-mono text-xs text-slate-400">{selectedTx.id}</span>
              </div>
            </div>

            <div className="flex gap-3 mt-2">
              <button 
                id="modal-details-close-btn"
                onClick={() => setSelectedTx(null)}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans font-bold text-xs tracking-wider rounded-xl transition-all text-center cursor-pointer"
              >
                Close Details
              </button>
              <button 
                id="modal-details-delete-btn"
                onClick={() => {
                  deleteTransaction(selectedTx.id);
                  setSelectedTx(null);
                }}
                className="flex-1 py-3 bg-rose-50 hover:bg-rose-100 text-rose-600 font-sans font-bold text-xs tracking-wider rounded-xl transition-all text-center cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Entry</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
